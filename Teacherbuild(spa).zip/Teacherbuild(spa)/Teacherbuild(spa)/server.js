const express = require('express')
const app = express()
app.use(express.json());
const port = 7000

const cors = require('cors')
app.use(cors({
    origin: "http://localhost:3000",
    credentials: true
}))

const bcrypt = require('bcrypt');

const mongoose = require('mongoose');
const { type } = require('os');
mongoose.connect('mongodb://127.0.0.1:27017/teacherdb').then(() => console.log("Connected to MongoDB on port " + port));

const osType = type();
console.log(osType);

require('dotenv').config()
const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
        user: `${process.env.SMTP_UNAME}`,
        pass: `${process.env.SMTP_PASS}`
    },
});

// const uuid = require("uuid");
// uuid.v4();
// or
const { v4: uuidv4 } = require('uuid')
// But we want the function name to be uuidv4, not just v4 , So we rename it to uuidv4

const jwt = require("jsonwebtoken");

const cookieParser = require("cookie-parser")   // to read cookie for jwt
app.use(cookieParser());

function verifyjsontoken(req, res, next)
{
    // we need cookieParser here so that it can read cookie here , so install it
    let token = req.cookies.authToken
    if (token)
    {
        try
        {
            const decoded = jwt.verify(token, process.env.JWT_SKEY)
            console.log(decoded)
            req.utype = decoded.role
            req.id = decoded.id
            return next()
        }
        catch (e)
        {
            return res.send({ statuscode: -5, msg: "Invalid Token" })
        }
    }

    const refreshtoken = req.cookies.refreshToken;
    if (!refreshtoken)
    {
        return res.send({ statuscode: -5, msg: "Session expired. Please log in again." })
    }
    try
    {
        const decoded = jwt.verify(refreshtoken, process.env.JWT_REFRESH_SKEY)
        const newauthToken = jwt.sign({ id: decoded.id, role: decoded.role }, process.env.JWT_SKEY, { expiresIn: "15m" })

        res.cookie("authToken", newauthToken, {
            httpOnly: true,
            secure: false,
            sameSite: "lax",
            maxAge: 15 * 60 * 1000,
        });

        req.utype = decoded.role
        req.id = decoded.id
        return next()
    }
    catch (e)
    {
        return res.send({ statuscode: -5, msg: "Invalid refresh Token" })
    }
}

function verifyadmin(req, res, next)
{
    console.log(req.utype)
    if (req.utype === "admin")
    {
        return next();
    }
    else
    {
        return res.send({ statuscode: -5, msg: "Only Admin can access" })
    }
}

const SignupSchema = new mongoose.Schema({ name: String, phone: String, email: { type: String, unique: true }, rollno: String, password: String, semester: String, department: String, usertype: String, actstatus: Boolean, token: String, googleId: String }, { versionKey: false })
const SignupModel = mongoose.model("signup", SignupSchema, "signup");// internal name , schema_name , real collection name

app.post("/api/signup", async (req, res) => 
{
    try 
    {
        const acttoken = uuidv4();
        console.log(acttoken)

        const encryp_pass = bcrypt.hashSync(req.body.pass, 10)

        const newrecord = new SignupModel({ name: req.body.name, phone: req.body.phone, email: req.body.email, rollno: req.body.rollno, password: encryp_pass, department: req.body.dep, semester: req.body.sem, usertype: "normal", actstatus: false, token: acttoken, googleId: "" })
        const result = await newrecord.save();  // it will save the record into real collection

        if (result) 
        {
            const mailOptions = {
                from: 'sameerwalia13@gmail.com', // transporter username email
                to: req.body.email,             // user's email id
                subject: 'Activation Mail from Teacher Website.com',
                html: `Dear ${req.body.name}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${acttoken}'>Activate Account<a/>`
            };

            transporter.sendMail(mailOptions, (error, info) =>
            {
                if (error)
                {
                    console.log(error);
                    res.send({ statuscode: 2 })
                }
                else
                {
                    console.log("Email sent: " + info.response);
                    res.send({ statuscode: 1 })
                }
            });
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Error while Signing Up , try again" })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.put("/api/activateuseraccount", async (req, res) =>
{
    try
    {
        const updateresult = await SignupModel.updateOne({ token: req.body.code }, { $set: { actstatus: true } });
        if (updateresult.modifiedCount === 1)
        {
            res.send({ statuscode: 1 })
        }
        else
        {
            res.send({ statuscode: 0 })
        }
    }
    catch (e)
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.post("/api/resendmail", async (req, res) =>
{
    try 
    {
        const user = await SignupModel.findOne({ email: req.body.email });
        if (user === null) 
        {
            res.send({ statuscode: 0, msg: "User not found with given email " });
        }
        else
        {
            const updatetoken = await SignupModel.updateOne({ email: req.body.email }, { $set: { actstatus: false } })
            if (updatetoken.modifiedCount === 1) 
            {
                const mailOptions = {
                    from: 'sameerwalia13@gmail.com', // transporter username email
                    to: req.body.email,             // user's email id
                    subject: 'Activation Mail from Teacher Website.com',
                    html: `Dear ${user.name}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${user.token}'>Activate Account<a/>`
                };

                transporter.sendMail(mailOptions, (error, info) =>
                {
                    if (error)
                    {
                        console.log(error);
                        res.send({ statuscode: 2 })
                    }
                    else
                    {
                        console.log("Email resents: " + info.response);
                        res.send({ statuscode: 1 })
                    }
                });
            }
            else
            {
                const mailOptions = {
                    from: 'sameerwalia13@gmail.com',
                    to: req.body.email,
                    subject: 'Activation Mail from SuperMarket.com',
                    html: `Dear ${user.name}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${user.token}'>Activate Account<a/>`
                };

                transporter.sendMail(mailOptions, (error, info) => 
                {
                    if (error) 
                    {
                        console.log(error);
                        res.send({ statuscode: 2 });
                    }
                    else 
                    {
                        console.log("Email resent: " + info.response);
                        res.send({ statuscode: 1 });
                    }
                });
            }
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
});

app.post("/api/login", async (req, res) => 
{
    try 
    {

        const result = await SignupModel.findOne({ email: req.body.email })
        // const result = await SignupModel.findOne({ email: req.body.email }).select("-phone");
        // .select("-phone"); = so phone is not shown in console.log and also phone:result.phone cannot be store in respdata
        console.log(result)
        if (result === null) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            if (bcrypt.compareSync(req.body.pass, result.password))
            {

                const jsontoken = jwt.sign({ id: result._id, role: result.usertype }, process.env.JWT_SKEY, { expiresIn: "15min" })
                const refreshjsontoken = jwt.sign({ id: result._id, role: result.usertype }, process.env.JWT_REFRESH_SKEY, { expiresIn: "7d" })

                const respdata = { _id: result._id, name: result.name, phone: result.phone, email: result.email, rollno: result.rollno, semester: result.semester, department: result.department, usertype: result.usertype, actstatus: result.actstatus }

                res.cookie("authToken", jsontoken, {   // authtoken is name of cookie and jsontoken is its value
                    httpOnly: true,
                    secure: false,    // when we launch the site , make is true
                    sameSite: "lax",   // strict , lax , none 
                    maxAge: 15 * 60 * 1000,   // expiry time , time should be in milliseconds , 15 min
                });

                res.cookie("refreshToken", refreshjsontoken, {   // authtoken is name of cookie and jsontoken is its value
                    httpOnly: true,
                    secure: false,    // when we launch the site , make is true
                    sameSite: "lax",   // strict , lax , none 
                    maxAge: 7 * 24 * 60 * 60 * 1000,   // expiry time , time should be in milliseconds , 7 days
                });

                res.send({ statuscode: 1, userdata: respdata })
            }
            else
            {
                res.send({ statuscode: 0 })
            }
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.post("/api/google-login", async (req, res) =>
{
    try
    {
        const { email, name, googleId } = req.body;

        let user = await SignupModel.findOne({ email: email });

        if (user === null)
        {
            // create new Google user
            const newrecord = new SignupModel({
                name, email, phone: "", rollno: "", password: "", semester: "", department: "", usertype: "normal",
                actstatus: true,  // GOOGLE EMAIL IS ALREADY VERIFIED
                token: "", googleId: googleId
            });

            user = await newrecord.save();
        }

        // create JWT cookies like normal login
        const jsontoken = jwt.sign({ id: user._id, role: user.usertype }, process.env.JWT_SKEY, { expiresIn: "15min" });
        const refreshjsontoken = jwt.sign({ id: user._id, role: user.usertype }, process.env.JWT_REFRESH_SKEY, { expiresIn: "7d" });

        // set cookies
        res.cookie("authToken", jsontoken, {
            httpOnly: true,
            secure: false,
            sameSite: "lax",
            maxAge: 15 * 60 * 1000
        });

        res.cookie("refreshToken", refreshjsontoken, {
            httpOnly: true,
            secure: false,
            sameSite: "lax",
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        const respdata = {
            _id: user._id, name: user.name, email: user.email, rollno: user.rollno, semester: user.semester,
            department: user.department, usertype: user.usertype, actstatus: user.actstatus
        };

        res.send({ statuscode: 1, userdata: respdata });

    }
    catch (e)
    {
        console.log(e);
        res.send({ statuscode: -1 });
    }
});

app.put("/api/changepassword", async (req, res) => 
{
    try
    {
        const result = await SignupModel.findOne({ email: req.body.email })
        console.log(result)
        if (result === null)
        {
            res.send({ statuscode: 0 })
        }
        else
        {
            if (bcrypt.compareSync(req.body.currpass, result.password))
            {
                const encryp_newpass = bcrypt.hashSync(req.body.newpass, 10)
                const updatepass = await SignupModel.updateOne({ email: req.body.email }, { $set: { password: encryp_newpass } })
                if (updatepass.modifiedCount === 1) 
                {
                    res.send({ statuscode: 1 })
                }
                else 
                {
                    res.send({ statuscode: 0 })
                }
            }
            else
            {
                res.send({ statuscode: 0 })
            }
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.post("/api/logout", (req, res) => 
{
    try 
    {
        res.clearCookie("authToken");
        res.clearCookie("refreshToken");
        res.send({ statuscode: 1 })
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
});

app.get("/api/fetchoneuserdata/:useremail", verifyjsontoken, async (req, res) =>
{
    try
    {
        const result = await SignupModel.find({ email: req.params.useremail })
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, oneuserdata: result[0] })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallusers", verifyjsontoken, verifyadmin, async (req, res) =>
{
    try
    {
        const result = await SignupModel.find()
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, usersdata: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.put("/api/updateuserprofile", async (req, res) =>
{
    try
    {
        const updateresult = await SignupModel.updateOne({ email: req.body.uemail }, { $set: { name: req.body.name, phone: req.body.phone, rollno: req.body.rollno, department: req.body.dep, semester: req.body.sem } });

        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})


app.post("/api/contact", async (req, res) =>
{
    try
    {
        const mailOptions = {
            from: 'sameerwalia13@gmail.com', // transporter username email
            to: 'sameerwalia13@gmail.com',  // any email id of admin where u want to send email
            replyTo: req.body.email,
            subject: 'Message from  Teacher Feedback website- Contact Us Page',
            html: `<b>Name:- </b>${req.body.name}<br/><b>Email:- </b>${req.body.email}<br/><b>Message:- </b>${req.body.message}`
        };

        transporter.sendMail(mailOptions, (error, info) =>
        {
            if (error)
            {
                console.log(error);
                res.send({ statuscode: 0 })
            }
            else
            {
                console.log("Email sent: " + info.response);
                res.send({ statuscode: 1 })
            }
        });
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }

})

app.get("/api/fetchoneuser/:userid", async (req, res) =>
{
    try
    {
        const result = await SignupModel.find({ _id: req.params.userid })
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, oneuserdata: result[0] })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.put("/api/updateoneuser", async (req, res) =>
{
    try
    {
        const updateresult = await SignupModel.updateOne({ _id: req.body.uid }, { $set: { name: req.body.name, phone: req.body.phone, email: req.body.email, rollno: req.body.rollno, department: req.body.dep, semester: req.body.sem } });

        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/deluser", async (req, res) =>
{
    try
    {
        const result = await SignupModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1)
        {
            res.send({ statuscode: 1 })
        }
        else
        {
            res.send({ statuscode: 0 })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/searchuser", async (req, res) =>
{
    try
    {
        const result = await SignupModel.find({ email: req.query.email })
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, userdata: result[0] })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchallcontacts", async (req, res) =>
{
    try
    {
        const result = await contactmodel.find();
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, contactdata: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})
app.delete("/api/delcontact", async (req, res) =>
{
    try
    {
        const result = await contactmodel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Contact deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Contact not deleted" })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

const teacherSchema = mongoose.Schema({ name: String, phone: String, email: String, department: String, subject: String, subjectcode: String }, { versionKey: false })
const teachermodel = mongoose.model("teacher", teacherSchema, "teacher")

app.post("/api/addteacher", async (req, res) =>
{
    try
    {
        const teacher = new teachermodel({ name: req.body.name, email: req.body.email, phone: req.body.phone, department: req.body.dep, subject: req.body.subjectname, subjectcode: req.body.subjectcode })
        const result = await teacher.save();  // it will save the record into real collection

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallteachers", async (req, res) =>
{
    try
    {
        const result = await teachermodel.find()
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, teacherdata: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchoneteacher", async (req, res) =>
{
    try
    {
        const result = await teachermodel.find({ _id: req.query.id })
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, oneteacherdata: result[0] })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.put("/api/updateteacher", async (req, res) =>
{
    try
    {
        const updateresult = await teachermodel.updateOne({ _id: req.body.tid }, { $set: { name: req.body.name, phone: req.body.phone, email: req.body.email, department: req.body.dep, subjectname: req.body.subjectname, subjectcode: req.body.subjectcode } })
        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delteacher/:id", async (req, res) =>
{
    try
    {
        const result = await teachermodel.deleteOne({ _id: req.params.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Teacher Data deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Teacher Data not deleted" })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallteacher", async (req, res) =>
{
    try
    {
        const result = await teachermodel.find()
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, teacherdata: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchteachername/:nid", async (req, res) =>
{
    try
    {
        const result = await teachermodel.findOne({ _id: req.params.nid })
        if (result === null) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, teacherdata: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})


const FeedbackSchema = mongoose.Schema({ name: String, thougts: String, rate1: Number, rate2: Number, rate3: Number, rate4: Number, rate5: Number, rate6: Number, rate7: Number, rate8: Number, rate9: Number, rate10: Number, }, { versionKey: false })
const FeedbackModel = mongoose.model("feedback", FeedbackSchema, "feedback");// internal name , schema_name , real collection name


app.post("/api/submitfeedback", async (req, res) => 
{
    try 
    {
        const newrecord = new FeedbackModel({ name: req.body.name, thougts: req.body.thoughts, rate1: req.body.rating1, rate2: req.body.rating2, rate3: req.body.rating3, rate4: req.body.rating4, rate5: req.body.rating5, rate6: req.body.rating6, rate7: req.body.rating7, rate8: req.body.rating8, rate9: req.body.rating9, rate10: req.body.rating10 })
        const result = await newrecord.save();  // it will save the record into real collection

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Feedback Not Submitted" })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/allteacherfeed", async (req, res) =>
{
    try
    {
        const result = await teachermodel.find()
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, teacherdata: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/uniquefeed/:name", async (req, res) =>
{
    try
    {
        const result = await FeedbackModel.find({ name: req.params.name })
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, uniquefeedback: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchoneteacher_sub_code/:name", async (req, res) =>
{
    try
    {
        const result = await teachermodel.findOne({ name: req.params.name })
        if (result === null) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, sub_subcode: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/getallfeedbacks", async (req, res) =>
{
    try
    {
        const result = await FeedbackModel.find()
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, feedbacks: result })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})


const ResetPassSechema = new mongoose.Schema({ username: String, exptime: Date, token: String }, { versionKey: false })
const restPassModel = mongoose.model("resetpass", ResetPassSechema, "resetpass");// internal name, schema_name, real collection_name

app.get("/api/forgotpassword", async (req, res) => 
{
    try 
    {
        const result = await SignupModel.findOne({ email: req.query.un })
        console.log(result)
        if (result === null)
        {
            res.send({ statuscode: 3 })
        }
        else
        {
            const passtoken = uuidv4();

            const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
            const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
            const fifteenminOffset = 15 * 60 * 1000; // IST offset in milliseconds (15 minutes)
            const expiretime = new Date(currentDateUTC.getTime() + ISTOffset + fifteenminOffset)  // add 15 min more

            const newrecord = new restPassModel({ username: req.query.un, exptime: expiretime, token: passtoken })
            const result2 = newrecord.save()
            if (result2)
            {
                const mailOptions = {
                    from: 'sameerwalia13@gmail.com', // transporter username email
                    to: req.query.un,             // user's email id
                    subject: 'Reset Password Mail from SuperMarket.com',
                    html: `Dear ${result.name}<br/><br/>Click on the Following Link to Reset your Password :-.<br/><br/><a href='http://localhost:3000/resetpassword?code=${passtoken}'>Reset Password<a/>`
                };

                transporter.sendMail(mailOptions, (error, info) =>
                {
                    if (error)
                    {
                        console.log(error);
                        res.send({ statuscode: 2 })
                    }
                    else
                    {
                        console.log("Email sent: " + info.response);
                        res.send({ statuscode: 1 })
                    }
                });

            }
            else
            {
                res.send({ statuscode: 0 })
            }

        }

    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
});


app.get("/api/checktoken", async (req, res) =>
{
    const currentDateUTC = new Date(); // Get the current Date in GMt/UTC
    const ISTOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds (5 hours 30 minutes)
    const currtime = new Date(currentDateUTC.getTime() + ISTOffset)
    console.log(currtime)

    try
    {
        const result = await restPassModel.findOne({ token: req.query.token })
        console.log(result)
        {
            if (result === null)
            {
                res.send({ statuscode: 0 })
            }
            else
            {
                if (currtime < result.exptime)   // 5:20 < 5:30
                {
                    res.send({ statuscode: 1 })
                }
                else
                {
                    // delete Token after it get expired
                    const result2 = await restPassModel.deleteOne({ token: req.query.token })
                    if (result2.deletedCount === 1) 
                    {
                        res.send({ statuscode: 0 })
                    }
                    else 
                    {
                        res.send({ statuscode: 2 })
                    }
                }
            }
        }
    }
    catch (e)
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})


app.put("/api/resetpassword", async (req, res) => 
{
    try
    {
        const result = await restPassModel.findOne({ token: req.body.token })
        console.log(result)
        if (result === null)
        {
            res.send({ statuscode: 0 })
        }
        else
        {
            const encryp_newpass = bcrypt.hashSync(req.body.newpass, 10)
            const updatepass = await SignupModel.updateOne({ email: result.username }, { $set: { password: encryp_newpass } })
            if (updatepass.modifiedCount === 1) 
            {
                res.send({ statuscode: 1 })
            }
            else 
            {
                res.send({ statuscode: 0 })
            }

        }
    }
    catch (e)
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.use(express.static(__dirname));

app.get("/*", (req, res) =>
{
    res.sendFile(__dirname + "\\index.html")
})

app.listen(port, () =>
{
    console.log(`Server is running on port ${port}`)
})