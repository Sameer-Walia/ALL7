import './App.css';
import Header from './components/Header';
import Siteroutes from './components/Siteroutes';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { createContext, useEffect, useState } from 'react';
import CommonHeader from './components/CommonHeader';

const userContext = createContext(null)

function App() {

  const[udata , setudata] = useState(null);

  useEffect(()=>
  {
    if(sessionStorage.getItem("userdata")!==null)
    {
      setudata(JSON.parse(sessionStorage.getItem("userdata")));
    }
  },[])

  return (
    <>
      <userContext.Provider value={{udata , setudata}}>
        {
          udata===null?<Header/>:<CommonHeader/>
        }
        <Siteroutes/>
      </userContext.Provider>
      <ToastContainer theme="colored"/>
    </>
  );
}

export default App;
export{userContext}
