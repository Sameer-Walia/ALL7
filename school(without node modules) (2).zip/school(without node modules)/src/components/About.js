import React from 'react'
import Footer from './Footer';

function About() {
    return(
        <>
            <section className="inner-banner py-5">
                <div className="w3l-breadcrumb py-lg-5">
                    <div className="container pt-4 pb-sm-4">
                        <h4 className="inner-text-title pt-5">About Us</h4>
                        <ul className="breadcrumbs-custom-path">
                            <li><a href="index.html">Home</a></li>
                            <li className="active"><i className="fas fa-angle-right"></i>About Us</li>
                        </ul>
                    </div>
                </div>
            </section>

            <section className="w3l-servicesblock py-5 mb-lg-5" id="about">
                <div className="container py-md-5 py-4">
                    <div className="row pb-xl-5 align-items-center">
                        <div className="col-lg-6 position-relative home-block-3-left pb-lg-0 pb-5">
                            <div className="position-relative">
                                <img src="assets/images/img1.jpg" alt="" className="img-fluid radius-image"/>
                            </div>
                            <div className="imginfo__box">
                                <h6 className="imginfo__title">Get a Appointment Today!</h6>
                                <p>Nemo enim ipsam oluptatem quia oluptas<br/> sit aspernatur aut odit aut fugit. </p>
                                <a href="tel:http://1(800)7654321"><i className="fas fa-phone-alt"></i> 1-800-654-3210</a>
                            </div>
                        </div>
                        <div className="col-xl-5 col-lg-6 offset-xl-1 mt-lg-0 mt-5 pt-lg-0 pt-5">
                            <h3 className="title-style">We Are The Best Choice For Your Child</h3>
                            <p className="mt-4">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                                ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet consectetur adipisicing
                                elit.</p>
                            <ul className="mt-4 list-style-lis pt-lg-1">
                                <li><i className="fas fa-check-circle"></i>Special Education</li>
                                <li><i className="fas fa-check-circle"></i>Access more then 100K online courses</li>
                                <li><i className="fas fa-check-circle"></i>Traditional Academies</li>
                            </ul>
                            <a href="contact.html" className="btn btn-style mt-5">Apply Now</a>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3-stats pt-4 pb-5" id="stats">
                <div className="container pb-md-5 pb-4">
                    <div className="title-main text-center mx-auto mb-md-5 mb-4"style={{ maxWidth: '500px' }}>
                        <p className="text-uppercase">Our Statistics</p>
                        <h3 className="title-style">We are Proud to Share with You</h3>
                    </div>
                    <div className="row text-center pt-4">
                        <div className="col-md-3 col-6">
                            <div className="counter">
                                <img src="assets/images/icon-1.png" alt="" className="img-fluid"/>
                                    <div className="timer count-title count-number mt-sm-1" data-to="36076" data-speed="1500"></div>
                                    <p className="count-text">Students Enrolled</p>
                            </div>
                        </div>
                        <div className="col-md-3 col-6">
                            <div className="counter">
                                <img src="assets/images/icon-2.png" alt="" className="img-fluid"/>
                                    <div className="timer count-title count-number mt-3" data-to="786" data-speed="1500"></div>
                                    <p className="count-text">Our Branches</p>
                            </div>
                        </div>
                        <div className="col-md-3 col-6 mt-md-0 mt-5">
                            <div className="counter">
                                <img src="assets/images/icon-3.png" alt="" className="img-fluid"/>
                                    <div className="timer count-title count-number mt-3" data-to="3630" data-speed="1500"></div>
                                    <p className="count-text">Total Courses</p>
                            </div>
                        </div>
                        <div className="col-md-3 col-6 mt-md-0 mt-5">
                            <div className="counter">
                                <img src="assets/images/icon-4.png" alt="" className="img-fluid"/>
                                    <div className="timer count-title count-number mt-3" data-to="6300" data-speed="1500"></div>
                                    <p className="count-text">Awards Won</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-index4 py-5" id="testimonials">
                <div className="container py-md-5 py-4">
                    <div className="content-slider text-center">
                        <div className="clients-slider">
                            <div className="mask">
                                <ul>
                                    <li className="anim1">
                                        <img src="assets/images/testi1.jpg" className="img-fluid rounded-circle"
                                            alt="client image" />
                                        <blockquote className="quote"><q>Duis aute irure dolor in reprehenderit in voluptate
                                            velit esse
                                            cillum dolore eu. Excepteur sint occaecat cupidatat
                                            non proident, sunt in culpa qui officia deserunt mollit anim id est
                                            laborum.
                                        </q> </blockquote>
                                        <div className="source">- Mario Spe</div>
                                    </li>

                                    <li className="anim2">
                                        <img src="assets/images/testi2.jpg" className="img-fluid rounded-circle"
                                            alt="client image" />
                                        <blockquote className="quote"><q>Sed ut perspiciatis unde omnis iste natus error sit
                                            voluptatem
                                            accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab
                                            illo
                                            inventore.
                                        </q> </blockquote>
                                        <div className="source">- Petey Cru</div>
                                    </li>
                                    <li className="anim3">
                                        <img src="assets/images/testi3.jpg" className="img-fluid rounded-circle "
                                            alt="client image" />
                                        <blockquote className="quote"><q>Lorem ipsum dolor sit amet, consectetur adipiscing
                                            elit, sed do
                                            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                            veniam,
                                            quis nostrud exercitation.
                                        </q> </blockquote>
                                        <div className="source">- Anna Sth</div>
                                    </li>
                                    <li className="anim4">
                                        <img src="assets/images/testi1.jpg" className="img-fluid rounded-circle"
                                            alt="client image" />
                                        <blockquote className="quote"><q>Duis aute irure dolor in reprehenderit in voluptate
                                            velit esse
                                            cillum dolore eu. Excepteur sint occaecat cupidatat
                                            non proident, sunt in culpa qui officia deserunt mollit anim id est
                                            laborum.
                                        </q> </blockquote>
                                        <div className="source">- Gail For</div>
                                    </li>
                                    <li className="anim5">
                                        <img src="assets/images/testi2.jpg" className="img-fluid rounded-circle"
                                            alt="client image" />
                                        <blockquote className="quote"><q>Lorem ipsum dolor sit amet, consectetur adipiscing
                                            elit, sed do
                                            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                            veniam,
                                            quis nostrud exercitation.
                                        </q> </blockquote>
                                        <div className="source">- Boye Fra</div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-team-13 py-5" id="team">
                <div className="container py-md-5 py-4">
                    <div className="title-main text-center mx-auto mb-md-5 mb-4" style={{ maxWidth: '500px' }}>
                        <p className="text-uppercase">Our Team</p>
                        <h3 className="title-style">Meet our Teachers</h3>
                    </div>
                    <div className="row text-center left-side">
                        <div className="col-lg-3 col-6">
                            <div className="image-one">
                                <a href="#team">
                                    <img src="assets/images/team1.png" className="arrow-png img-responsive" />
                                    <h4>Emma Watson</h4>
                                    <div className="buttons-teams2 mt-2">
                                        <a href="#team"><i className="fab fa-facebook-square"></i></a>
                                        <a href="#team"><i className="fab fa-twitter-square"></i></a>
                                        <a href="#team"><i className="fab fa-google-plus-square"></i></a>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-3 col-6">
                            <div className="image-one">
                                <a href="#team">
                                    <img src="assets/images/team2.png" className="arrow-png img-responsive"/>
                                        <h4>Enrique Lal</h4>
                                        <div className="buttons-teams2 mt-2">
                                            <a href="#team"><i className="fab fa-facebook-square"></i></a>
                                            <a href="#team"><i className="fab fa-twitter-square"></i></a>
                                            <a href="#team"><i className="fab fa-google-plus-square"></i></a>
                                        </div>
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-3 col-6 mt-lg-0 mt-4">
                            <div className="image-one">
                                <a href="#team">
                                    <img src="assets/images/team3.png" className="arrow-png img-responsive"/>
                                        <h4>Smith Ker</h4>
                                        <div className="buttons-teams2 mt-2">
                                            <a href="#team"><i className="fab fa-facebook-square"></i></a>
                                            <a href="#team"><i className="fab fa-twitter-square"></i></a>
                                            <a href="#team"><i className="fab fa-google-plus-square"></i></a>
                                        </div>
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-3 col-6 mt-lg-0 mt-4">
                            <div className="image-one">
                                <a href="#team">
                                    <img src="assets/images/team4.png" className="arrow-png img-responsive"/>
                                        <h4>Forkler Lee</h4>
                                        <div className="buttons-teams2 mt-2">
                                            <a href="#team"><i className="fab fa-facebook-square"></i></a>
                                            <a href="#team"><i className="fab fa-twitter-square"></i></a>
                                            <a href="#team"><i className="fab fa-google-plus-square"></i></a>
                                        </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-about-2 pb-5 pt-4">
                <div className="container pb-md-5 pb-4">
                    <div className="row align-items-center justify-content-between">
                        <div className="col-lg-6 about-2-secs-right mb-lg-0 mb-4 text-center pe-lg-4">
                            <img src="assets/images/image.jpg" alt="" className="img-fluid radius-image m-auto" />
                        </div>
                        <div className="col-lg-6 about-2-secs-left ps-lg-5">
                            <p className="text-uppercase">Our Environment</p>
                            <h3 className="title-style mb-sm-3 mb-2">Active Learning, Expert Teachers & Safe Environment</h3>
                            <p>Consectetur adipiscing elit. Aliquam sit amet
                                efficitur tortor.Uspendisse efficitur orci urna. In et augue ornare, tempor massa in, luctus
                                sapien. In et augue ornare, tempor massa.</p>
                            <div className="d-flex align-items-center mt-5">
                                <a className="btn btn-style btn-style-3" href="contact.html">Contact Us</a>
                                <a className="btn btn-style-primary ms-4" href="contact.html">Learn More <i
                                    className="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-call-to-action-6">
                <div className="container py-md-5 py-sm-4 py-5">
                    <div className="d-lg-flex align-items-center justify-content-between">
                        <div className="left-content-call">
                            <h3 className="title-big">Call To Enroll Your Child</h3>
                            <p className="text-white mt-1">Begin the change today!</p>
                        </div>
                        <div className="right-content-call mt-lg-0 mt-4">
                            <ul className="buttons">
                                <li className="phone-sec me-lg-4"><i className="fas fa-phone-volume"></i>
                                    <a className="call-style-w3" href="tel:+1(23) 456 789 0000">+1(23) 456 789 0000</a>
                                </li>
                                <li><a href="contact.html" classNameName="btn btn-style btn-style-2 mt-lg-0 mt-3">Join for free</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

        <Footer/>
        </>
    )
}

export default About;
