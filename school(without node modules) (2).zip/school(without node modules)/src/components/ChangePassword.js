import React, { useContext, useEffect } from 'react'
import { toast } from 'react-toastify';
import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom"
import { faEnvelope } from '@fortawesome/free-solid-svg-icons'
import { faLock } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Footer from './Footer';
import { userContext } from '../App';


function ChangePassword() {


    const [curpass, setcurpass] = useState();
    const [newpass, setnewpass] = useState();
    const [cnewpass, setcnewpass] = useState();

    const{udata , setudata} = useContext(userContext)

    
    const navi = useNavigate();

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
    },[])

    async function onchangepassword(e) {
        
        e.preventDefault()
         const uemail = udata.email
         const apidata = {curpass , newpass , uemail}

        try 
        {
            if(newpass===cnewpass)
            {
                const resp = await axios.put("http://localhost:8000/api/changepassword" , apidata)
                if (resp.status === 200) 
                {
                    if (resp.data.statuscode === 0) 
                    {
                        toast.warn("Incorrect Current Password")
                    }
                    else 
                    {
                        toast.success("Password changed successfully");
                        setudata(null);
                        sessionStorage.clear();
                        navi("/login")
                    }
                }
                else 
                {
                    alert("Some Problem Occured")
                }
            }
            else
            {
                toast.warn("New Password and confirm new password does not match")
            }
        }
        catch (e) {
            toast.error(e.message)
        }
    }



    return (
        <>
            <section className="inner-banner py-5">
                <div className="w3l-breadcrumb py-lg-5">
                    <div className="container pt-4 pb-sm-4">
                        <h4 className="inner-text-title pt-5">Change Password</h4>
                        <ul className="breadcrumbs-custom-path">
                            <Link to="/" classNameName="nav-link active" aria-current="page">Home</Link>
                            <li className="active"><i className="fas fa-angle-right"></i>Change Password</li>
                        </ul>
                    </div>
                </div>
            </section>

            

            <div className="container">
                <div className="row mt-5">
                    <div className="col-sm-6 mt-5">
                        <img src={`assets/images/sign.jpg`} alt="" className="img-fluid" />
                    </div>
                    <div className="col-sm-6 text-center mt-5">

                        <h1 class="register-form-title ">Change Password</h1>

                        <form onSubmit={onchangepassword} class="register-form ">

                            <div class="input-container mt-5 ">

                                <input type="password" name="userpass" placeholder="" onChange={(e)=>setcurpass(e.target.value)}class="input-field" required />

                                <label class="input-label">
                                    <span><FontAwesomeIcon icon={faLock} /></span><span>Current Password</span>
                                </label>

                            </div>
                            <div class="input-container mt-4 ">

                                <input type="password" name="userpass" placeholder="" onChange={(e)=>setnewpass(e.target.value)}class="input-field" required />

                                <label class="input-label">
                                    <span><FontAwesomeIcon icon={faLock} /></span><span>New Password</span>
                                </label>

                            </div>
                            <div class="input-container mt-4 ">

                                <input type="password" name="userpass" placeholder="" onChange={(e)=>setcnewpass(e.target.value)}class="input-field" required />

                                <label class="input-label">
                                    <span><FontAwesomeIcon icon={faLock} /></span><span>Confirm New Password</span>
                                </label>

                            </div>

                            <input type="submit" className="register-button" value="Submit"/>
                            
                        </form>

                    </div>
                </div>
            </div>

      <Footer/>

        </>
    )
}

export default ChangePassword
