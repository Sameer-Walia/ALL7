import React, { useContext, useEffect, useState } from 'react'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Footer from './Footer'
import { useNavigate } from 'react-router-dom';
import { faUser } from '@fortawesome/free-solid-svg-icons'
import { faMobile } from '@fortawesome/free-solid-svg-icons'
import { faBuilding } from '@fortawesome/free-solid-svg-icons'
import { faListOl } from '@fortawesome/free-solid-svg-icons'
import { faPhone } from '@fortawesome/free-solid-svg-icons'
import { faEnvelope } from '@fortawesome/free-solid-svg-icons'
import { userContext } from '../App';
import { toast } from 'react-toastify';
import axios from 'axios';

function ComplaintHOD() {

    const{udata , setudata} = useContext(userContext)

    const [name, setname] = useState();
    const [email, setemail] = useState();
    const [rollno, setrollno] = useState();
    const [dep, setdep] = useState();
    const [sem, setsem] = useState();
    const [message, setmessage] = useState();

    const navi = useNavigate()

    useEffect(()=>
    {
        if(udata!==null)
        {
            setname(udata.name)
            setrollno(udata.rollno)
            setemail(udata.email)
            setdep(udata.department)
            setsem(udata.semester)
        }
    },[udata])

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
    },[])

    async function complaint(e)
    {
        e.preventDefault()
        const data = {name , email , rollno ,dep ,sem , currentDate , message}
        try
        {
            const resp = await axios.post("http://localhost:8000/api/complaint" , data)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    toast.success("Your Complaint is Submitted");
                    canceldb();
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warning(resp.data.msg)
                }
            }
            else
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error(e.message)
        }
    }
    function canceldb()
    {
        setmessage("")
    }

    const [currentDate, setCurrentDate] = useState();

    useEffect(() => {
        const today = new Date();
        const formattedDate = today.toISOString().split('T')[0]; // Format date to YYYY-MM-DD
        setCurrentDate(formattedDate);
    }, []);

    return (
    <>
        <section className="inner-banner py-5">
            <div className="w3l-breadcrumb py-lg-5">
                <div className="container pt-4 pb-sm-4">
                    <h4 className="inner-text-title pt-5">Complaint Us</h4>
                    <ul className="breadcrumbs-custom-path">
                        <li><a href="index.html">Home</a></li>
                        <li className="active"><i className="fas fa-angle-right"></i>Complaint Us</li>
                    </ul>
                </div>
            </div>
        </section>

        <div className="container">
                <div className="row mt-5">
                    <div className="col-sm-6">
                        <h1 className="register-form-title mt-5">Submit Your Complaint</h1>
                        <img src={`assets/images/complaint2.png`} alt="" className="img-fluid" height="700px" />
                    </div>
                    <div className="col-sm-6 text-center ">


                        <form name="form1" onSubmit={complaint} className="register-form" >

  
                            <div className="input-row mt-5">
                                <div className="input-container col">
                                    <input type="text" name="username" placeholder="" className="input-field" value={name} required readOnly/>
                                    <label className="input-label" >
                                        <span><FontAwesomeIcon icon={faUser} /></span><span>Username</span>
                                    </label>
                                </div>

                            </div>

                            <div className="input-container mt-4 ">

                                <input type="email" name="useremail" placeholder="" className="input-field" value={email} required readOnly/>

                                <label className="input-label">
                                    <span><FontAwesomeIcon icon={faEnvelope} /></span><span>Email</span>
                                </label>

                            </div>

                            

                            <div className="select-container mt-4">
                                <select
                                    name="department"
                                    className="select-box"
                                    required
                                    value={dep}
                                    readOnly
                                >
                                    <option value={dep}>{dep}</option>
                                </select>

                                <label className="select-label">
                                    <span><FontAwesomeIcon icon={faBuilding} /></span><span>Department</span>
                                </label>
                            </div>

                            <div className="input-row mt-4">
                                <div className="select-container col">
                                    <select
                                        name="Semester"
                                        className="select-box"
                                        required
                                        value={sem}
                                        readOnly
                                    >
                                        <option value={sem}>{sem}</option>

                                    </select>
                                    <label className="select-label">
                                        <span><FontAwesomeIcon icon={faListOl} /></span><span>Semester</span>
                                    </label>
                                </div>

                                <div className="input-container col">
                                    <input type="number" name="userrollno" placeholder="" className="input-field" value={rollno} required readOnly/>
                                    <label className="input-label">
                                        <span><FontAwesomeIcon icon={faMobile} /></span><span>Roll No.</span>
                                    </label>
                                </div>
                            </div>

                            <div class="input-container mt-4">
                                <input type="date" name="userdate" class="input-field" value={currentDate}  required readOnly />
                                <label class="input-label">
                                    <span>&#128197;</span>Date
                                </label>
                            </div>

                            <div className="input-container mt-4 ">

                                <textarea name="useremail" placeholder="" className="input-field" onChange={(e)=>setmessage(e.target.value)}required />

                                <label className="input-label">
                                    <span><FontAwesomeIcon icon={faEnvelope} /></span><span>Message</span>
                                </label>

                            </div>

                            <input type="submit" className="register-button" value="Submit"/>

                        </form>

                    </div>
                </div>
            </div>


        <Footer/>
    </>
  )
}

export default ComplaintHOD
