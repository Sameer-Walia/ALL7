import { Link } from "react-router-dom";


function Header() {

    return (
        <>
            <header id="site-header" className="fixed-top">
        <div className="container">
            <nav className="navbar navbar-expand-lg navbar-light">
                <Link to="/" className="navbar-brand" aria-current="page">
                    <i className="fas fa-graduation-cap"></i> Edu School
                </Link>
                <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarScroll">
                    <ul className="navbar-nav ms-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li className="nav-item sam1">
                             <Link to="/about" >About Us</Link>
                        </li>
                        <li className="nav-item sam">
                            <Link to="/signup" classNameName="cp" style={{ border: '2px solid var(--primary-color)', padding: '10px', borderRadius: 20 }} aria-current="page">Register</Link>
                        </li>

                        <li className="nav-item sam">
                            <Link to="/login" classNameName="cp" style={{ border: '2px solid var(--primary-color)', padding: '10px', borderRadius: 20 }} aria-current="page">Login</Link>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>

        </>
    )
}
export default Header;