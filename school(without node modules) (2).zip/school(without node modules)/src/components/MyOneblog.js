import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { FaArrowLeft  } from 'react-icons/fa';
import { FaUser } from 'react-icons/fa';
import { FaCalendarAlt } from 'react-icons/fa';
import { toast } from 'react-toastify';

function MyOneblog() {

    const [params] = useSearchParams();
    const blogid = params.get("blogid")
    const [oneblog , setoneblog] = useState([]);
    const navi = useNavigate();

    useEffect(()=>
    {
        if(blogid)
        {
            fetchoneblog();
        }
    },[blogid])

    function sam()
    {
        navi("/myblogs")
    }


    async function fetchoneblog()
    {
        try
        {
            const resp = await axios.get("http://localhost:8000/api/fetchoneblog?blogid="+blogid)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    setoneblog(resp.data.oneblogdata)
                }
                else if (resp.data.statuscode === 0) 
                {
                    setoneblog([]);
                }
            }
            else 
            {
                toast.error("some problem occured")
            }
        }
        catch (e) 
        {
            toast.error(e.message)
        }
    }

  return (
    <div>
        
        <div className="page-container11">
            <div className="blog-card-container11">
                <div className="blog-date11">
                    <FaCalendarAlt className="date-icon11" />
                    <span>{ new Date(oneblog.date).toDateString()}</span>
                </div>

                <h1 className="blog-title11">{oneblog.title}</h1>
                
                <div className="blog-author11">
                    <FaUser className="author-icon11" />
                    <span className="author-name11">{oneblog.name}</span>
                </div>

                <div className="blog-content11" dangerouslySetInnerHTML={{ __html: oneblog.content }} />

                <button onClick={sam} className="back-button11">
                    <FaArrowLeft className="back-icon11" />
                    <span>Back to Blogs</span>
                </button>
            </div>
        </div>
    </div>
  )
}

export default MyOneblog
