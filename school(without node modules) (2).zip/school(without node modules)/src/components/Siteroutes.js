import { Route, Routes } from "react-router-dom";
import Home from './Home';
import Signup from './Signup';
import Login from "./Login";
import Contact from "./Contact";
import Adminpanel from "./Adminpanel";
import User from "./admin/User";
import Footer from "./Footer";
import UpdateUser from "./admin/UpdateUser";
import About from "./About";
import ChangePassword from "./ChangePassword";
import Userdashboard from "./Userdashboard";
import Updateprofile from "./Updateprofile";
import AdminHome from "./AdminHome";
import Searchuser from "./admin/Searchuser";
import Admincontact from "./admin/Admincontact";
import ComplaintHOD from "./ComplaintHOD";
import HodComplaints from "./HodComplaints";
import Adminsyallabus from "./admin/Adminsyallabus";
import AdminsyallabusAdd from "./admin/AdminsyallabusAdd";
import AdminsyallabusUpdate from "./admin/AdminsyallabusUpdate";
import AdminNotes from "./admin/AdminNotes";
import AdminNotesAdd from "./admin/AdminNotesAdd";
import AdminNotesUpdate from "./admin/AdminsNotesUpdate";
import AdminPYQ from "./admin/Adminpyq";
import AdminPYQAdd from "./admin/AdminPYQAdd";
import AdminPYQUpdate from "./admin/AdminsPYQUpdate";
import AdminUtube from "./admin/AdminUtube";
import AdminUtubeAdd from "./admin/AdminUtubeAdd";
import AdminUtubeUpdate from "./admin/AdminsUtubeUpdate";
import AdminBooks from "./admin/AdminBooks";
import AdminBookAdd from "./admin/AdminBookAdd";
import AdminBooksUpdate from "./admin/AdminsBooksUpdate";
import PYQ from "./user/PYQ";
import Syllabus from "./user/Syllabus";
import Books from "./user/Books";
import Youtube from "./user/Youtube";
import Notes from "./user/Notes";
import Resouces from "./Resouces";
import ScrollToTop from './ScrollToTop';
import BlogCompose from "./BlogCompose";
import Adminblogs from "./admin/Adminblogs";
import Allblogs from "./Allblogs";
import Oneblog from "./Oneblog";
import Myblogs from "./Myblogs";
import MyOneblog from "./MyOneblog";
import BlogUpdate from "./BlogUpdate";

function Siteroutes()
{
    return(
        <>
            <ScrollToTop/>
            <Routes>
                <Route path="/" element={<Home/>}></Route>
                <Route path="/adminhome" element={<AdminHome/>}></Route>
                <Route path="/signup" element={<Signup/>}></Route>
                <Route path="/login" element={<Login/>}></Route>
                <Route path="/contact" element={<Contact/>}></Route>
                <Route path="/adminusers" element={<User/>}></Route>
                <Route path="/updateuser" element={<UpdateUser/>}></Route>
                <Route path="/about" element={<About/>}></Route>
                <Route path="/changepassword" element={<ChangePassword/>}></Route>
                <Route path="/userdashboard" element={<Userdashboard/>}></Route>
                <Route path="/updateprofile" element={<Updateprofile/>}></Route>
                <Route path="/searchuser" element={<Searchuser/>}></Route>
                <Route path="/admincontact" element={<Admincontact/>}></Route>
                <Route path="/complaint" element={<ComplaintHOD/>}></Route>
                <Route path="/complaintHod" element={<HodComplaints/>}></Route>
                <Route path="/adminsyallabus" element={<Adminsyallabus/>}></Route>
                <Route path="/addsyallabus" element={<AdminsyallabusAdd/>}></Route>
                <Route path="/updatesyallabus" element={<AdminsyallabusUpdate/>}></Route>
                <Route path="/adminnotes" element={<AdminNotes/>}></Route>
                <Route path="/addnotes" element={<AdminNotesAdd/>}></Route>
                <Route path="/updatenotes" element={<AdminNotesUpdate/>}></Route>
                <Route path="/adminpyq" element={<AdminPYQ/>}></Route>
                <Route path="/addpyq" element={<AdminPYQAdd/>}></Route>
                <Route path="/updatepyq" element={<AdminPYQUpdate/>}></Route>
                <Route path="/adminutube" element={<AdminUtube/>}></Route>
                <Route path="/addutube" element={<AdminUtubeAdd/>}></Route>
                <Route path="/updateutube" element={<AdminUtubeUpdate/>}></Route>
                <Route path="/adminbooks" element={<AdminBooks/>}></Route>
                <Route path="/addbook" element={<AdminBookAdd/>}></Route>
                <Route path="/updatebook" element={<AdminBooksUpdate/>}></Route>
                <Route path="/userpyq" element={<PYQ/>}></Route>
                <Route path="/usersyllabus" element={<Syllabus/>}></Route>
                <Route path="/userbook" element={<Books/>}></Route>
                <Route path="/userutube" element={<Youtube/>}></Route>
                <Route path="/usernotes" element={<Notes/>}></Route>
                <Route path="/resource" element={<Resouces/>}></Route>
                <Route path="/allblog" element={<Allblogs/>}></Route>
                <Route path="/composeblog" element={<BlogCompose/>}></Route>
                <Route path="/oneblog" element={<Oneblog/>}></Route>
                <Route path="/myoneblog" element={<MyOneblog/>}></Route>
                <Route path="/myblogs" element={<Myblogs/>}></Route>
                <Route path="/adminblogs" element={<Adminblogs/>}></Route>
                <Route path="/updateblog" element={<BlogUpdate/>}></Route>
            </Routes>
        </>
    )
}
export default Siteroutes;