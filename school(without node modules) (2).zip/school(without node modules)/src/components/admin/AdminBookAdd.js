import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminBookAdd() {

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();
    const [picture, setpicture] = useState();

    const navigate = useNavigate();

    async function submitBook(e)
    {
        e.preventDefault()
        try
        {
            const fdata = new FormData();
            fdata.append("services" , service)
            fdata.append("semesters" , semester)
            fdata.append("subjects" , subject)
            fdata.append("subjectcodes" , subjectcode)
            fdata.append("links" , link)

            if(picture!==null)
            {
                fdata.append("pictures",picture)
            }

            const resp = await axios.post("http://localhost:8000/api/addBook" , fdata)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Book Added Successfully")
                    navigate("/adminbooks");
                }
                else 
                {
                    toast.error("Youtube Cannot added Successfully.")
                }
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch(e)
        {
            toast.warn(e.message)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={submitBook}>
                        <h1>Add New Book</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject"  required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                        
                            <div class="form-group">
                                <label >Book Front Image</label>
                                <input type="file" name="ppic"  onChange={(e)=>setpicture(e.target.files[0])} /><br/>
                            </div>

                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link" required onChange={(e)=>setlink(e.target.value)}/>
                            </div>
                         
                            <div>
                                <input type="submit" className="register-button1" value="Submit"/>
                            </div>
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminBookAdd
