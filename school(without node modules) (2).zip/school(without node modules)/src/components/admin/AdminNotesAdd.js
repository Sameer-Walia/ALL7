import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminNotesAdd() {

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();

    const navigate = useNavigate();

    async function submitNotes(e)
    {
        e.preventDefault()
        try
        {
            const data = {service , semester, subject, subjectcode , link}

            const resp = await axios.post("http://localhost:8000/api/addNotes" , data)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Notes Added Successfully")
                    navigate("/adminnotes");
                }
                else 
                {
                    toast.error("Notes Cannot added Successfully.")
                }
            }
            else 
            {
                alert("Some error occured")
            }
    }
        catch(e)
        {
            toast.warn(e.message)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={submitNotes}>
                        <h1>Add New Notes</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject"  required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link" onChange={(e)=>setlink(e.target.value)}/>
                            </div>
                         
                         
                            <div>
                                <input type="submit" className="register-button1" value="Submit"/>
                            </div>
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminNotesAdd
