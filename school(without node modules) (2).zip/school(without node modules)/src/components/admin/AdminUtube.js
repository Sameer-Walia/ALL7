import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminUtube() {

    const [utube, setutube] = useState([])

    useEffect(() => {
        fetchallUtube();
    }, [])

    async function fetchallUtube()
    {
        
        try {
            const resp = await axios.get("http://localhost:8000/api/fetchallUtube")
            if (resp.status === 200) {
                if (resp.data.statuscode === 1) {
                    setutube(resp.data.utubedata)
                }
                else if (resp.data.statuscode === 0) {
                    setutube([]);
                }
            }
            else {
                toast.warn("Some Problem Occured")
            }
        }
        catch (err) {
            toast.error(err.message)
        }
    }

    async function delutube(id)
    {
        var confirm = window.confirm("Are u sure want to delete the Utube Link")
        if(confirm===true)
        {
            try
            {
                const resp = await axios.delete(`http://localhost:8000/api/delutube?id=${id}`)
                if(resp.status===200)
                {
                    if(resp.data.statuscode===1)
                    {
                        toast.success("Youtube Deleted Successfully")
                        fetchallUtube();
                    }
                    else if(resp.data.statuscode===0)
                    {
                        alert("PYQ not Deleted")
                    }
                }
            }
            catch(e)
            {
                toast.error(e.message)
            }
        }
    }
    return (
        <>
            <Adminpanel />
            <div className='content'>
                <section className="section">
                    <div className="section-content">
                        <h1 className="section-title">Admin Utube Data</h1>
                        <div className="user-count">
                            <Link to="/addutube"><input type='button' className="edit-button2" value="Add New YouTube" /></Link>
                        </div>
                        {
                            utube.length > 0 ?

                                <div className="table-container">
                                    <table width="100%">
                                        <thead>
                                            <tr className="table-header text-center" >
                                                <th className="table-header">Service</th>
                                                <th className="table-header">Semester</th>
                                                <th className="table-header">Subject</th>
                                                <th className="table-header">Subject Code</th>
                                                <th className="table-header">Link</th>
                                                <th className="table-header">Edit</th>
                                                <th className="table-header">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                utube.map((item, index) =>
                                                    <tr key={index} className="table-row">
                                                        <td className="table-cell">{item.service}</td>
                                                        <td className="table-cell">{item.semester}</td>
                                                        <td className="table-cell">{item.subject}</td>
                                                        <td className="table-cell">{item.subjectcode}</td>
                                                        <td className="table-cell">
                                                            <Link to={item.link} target="_blank" >
                                                                Link 
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <Link to={`/updateutube?uid=${item._id}`} className="edit-button">
                                                                Edit
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <button className="delete-button" onClick={()=>delutube(item._id)} >
                                                                Delete
                                                            </button>
                                                        </td>
                                                    </tr>
                                                )
                                            }

                                        </tbody>
                                    </table>
                                </div>
                                : <div class="no-user-message">No YouTube Added</div>
                        }
                    </div>
                </section>
            </div>
        </>
    )
}

export default AdminUtube
