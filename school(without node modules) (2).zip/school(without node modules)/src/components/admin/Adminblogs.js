import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import Adminpanel from '../Adminpanel'
import { useNavigate } from 'react-router-dom'

function Adminblogs() {

    const [blogdata, setblogdata] = useState([])
    const navi = useNavigate();

    useEffect(() => {
        fetchallblogs()
    }, [])

    async function fetchallblogs() {
        try {
            const resp = await axios.get("http://localhost:8000/api/fetchallblogs")

            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    setblogdata(resp.data.blogsdata)
                }
                else if (resp.data.statuscode === 0)
                {
                    setblogdata([]);
                }
            }
            else {
                toast.error("some problem occured")
            }
        }
        catch (e) {
            toast.error(e.message)
        }
    }

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
        else
        {
            var uinfo = JSON.parse(sessionStorage.getItem("userdata"))
            if(uinfo.usertype!=="admin")
            {
                navi("/login")
                toast.error("please login to access the admin page") 
            }
        }
    },[])

    async function ondelete(id)
    {
        try
        {
            var pass = window.confirm("Are you sure to Delete the Blog")
            if(pass===true)
            {
                const resp = await axios.delete(`http://localhost:8000/api/delblog?id=${id}`)
                if(resp.status===200)
                {
                    if(resp.data.statuscode===1)
                    {
                        toast.success(resp.data.msg)
                        fetchallblogs();
                    }
                    else if(resp.data.statuscode===0)
                    {
                        toast.warn(resp.data.msg)
                    }
                }
                else
                {
                    alert("some problem occured")
                }
            }
        }
        catch(e)
        {
            toast.error(e.message)
        }
    }


  return (
    <div>
        <Adminpanel/>
            <div className='content'>
                {
                    blogdata.length > 0 ?
                        <>
                            <h1 className="heading">Admin Blogs</h1>
                            {
                                blogdata.map((item, index) =>
                                <div className="contact-box mt-4" key={index}>
                                    <div className="contact-item">
                                        <div className="contact-header">
                                            <h2 className="contact-username">{item.title}</h2>
                                            <button className="delete-button" onClick={()=>ondelete(item._id)}>Delete</button>
                                        </div>
                                        <p><strong>Author :&nbsp;</strong> {item.name}</p>
                                        <p><strong>Created At :&nbsp;</strong> {new Date(item.date).toLocaleDateString()}</p>
                                        <p><strong>Content :</strong>{item.content}</p>
                                    </div>
                                </div>
                                )
                            }
                        </> : <h2 className='no-user-message'>No Blog Found</h2>
                }
            </div>
    </div>
  )
}

export default Adminblogs
