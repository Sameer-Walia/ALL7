import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { toast } from 'react-toastify'
import axios from 'axios'

function Admincontact() {

    const [contactdata, setcontactdata] = useState([])

    useEffect(() => {
        fetchallcontacts()
    }, [])

    async function fetchallcontacts() {
        try {
            const resp = await axios.get("http://localhost:8000/api/fetchallcontacts")

            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    setcontactdata(resp.data.contactdata)
                }
                else if (resp.data.statuscode === 0)
                {
                    setcontactdata([]);
                }
            }
            else {
                toast.error("some problem occured")
            }
        }
        catch (e) {
            toast.error(e.message)
        }
    }

    async function ondelete(id)
    {
        try
        {
            var pass = window.confirm("Are you sure to Delete")
            if(pass===true)
            {
                const resp = await axios.delete(`http://localhost:8000/api/delcontact?id=${id}`)
                if(resp.status===200)
                {
                    if(resp.data.statuscode===1)
                    {
                        toast.success(resp.data.msg)
                        fetchallcontacts()
                    }
                    else if(resp.data.statuscode===0)
                    {
                        toast.warn(resp.data.msg)
                    }
                }
                else
                {
                    alert("some problem occured")
                }
            }
        }
        catch(e)
        {
            toast.error(e.message)
        }
    }

    return (
        <div>
            <Adminpanel />
            <div className='content'>
                <section className="admin-contacts">

                    {
                        contactdata.length > 0 ?
                            <>
                                <h1 className="heading">Admin Contacts</h1>
                                {
                                    contactdata.map((item, index) =>
                                    <div className="contact-box mt-4" key={index}>
                                        <div className="contact-item">
                                            <div className="contact-header">
                                                <h2 className="contact-username">{item.name}</h2>
                                                <button className="delete-button" onClick={()=>ondelete(item._id)}>Delete</button>
                                            </div>
                                            <p><strong>Email:&nbsp;</strong> {item.email}</p>
                                            <p><strong>Subject:&nbsp;</strong> {item.Subject}</p>
                                            <p><strong>Message:&nbsp;</strong>{item.message}</p>
                                        </div>
                                    </div>
                                    )
                                }
                            </> : <h2 className='text-center con'>No Contact Found</h2>
                    }

                </section>
            </div>
        </div>
    )
}

export default Admincontact
