import React, { useEffect, useRef, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminBooksUpdate() {

    const [params] = useSearchParams();
    const bid = params.get("bid")
    const navigate = useNavigate()

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();
    const [picture, setpicture] = useState();
    const [imgname, setimgname] = useState();
    const fileInputRef = useRef(null);   // for cancel
   

    useEffect(()=>
    {
        if(bid!==null)
        {
            fetchutube()
        }
    },[bid])

    async function fetchutube()
    {
        try
        {
            const resp = await axios.get(`http://localhost:8000/api/fetchbook/${bid}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    const Books = resp.data.bookdata;
                    setservice(Books.service);
                    setsemester(Books.semester);
                    setsubject(Books.subject);
                    setsubjectcode(Books.subjectcode);
                    setimgname(Books.Picture);
                    setlink(Books.link);
                   
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("Cannot Fetch Youtube")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    async function updateBooks(e)
    {
        e.preventDefault()
        try
        {
            const fdata = new FormData();
            fdata.append("bookid" , bid)
            fdata.append("services" , service)
            fdata.append("semesters" , semester)
            fdata.append("subjects" , subject)
            fdata.append("subjectcodes" , subjectcode)
            fdata.append("links" , link)

            fdata.append("oldpicname" , imgname)

            if(picture!==null)
            {
                fdata.append("uppic",picture)
            }

            const resp = await axios.put("http://localhost:8000/api/updateBook" , fdata)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Book Updated Successfully")
                    canceldb();
                    navigate("/adminbooks");
                }
                else 
                {
                    toast.error("Book Cannot Updated Successfully.")
                }
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch(e)
        {
            toast.warn(e.message)
        }
    }
    function canceldb()
    {
        setservice("");
        setsemester("");
        setsubject("");
        setsubjectcode("");
        setimgname("");
        setlink("");
        setpicture(null)

        // Clear the file input field
        if (fileInputRef.current) 
        {
            fileInputRef.current.value = ''; // Reset the value to clear the input
        }
    }


    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={updateBooks}>
                        <h1>Edit Book</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" value={service} required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" value={semester} required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" value={subject} required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" value={subjectcode} required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>

                            <img src={`uploads/${imgname}`}  height="100"/>
                            &nbsp;&nbsp; Choose new image, if required<br/><br/>

                            <div class="form-group">
                                <label >Book Front Image</label>
                                <input type="file" name="ppic" ref={fileInputRef}  onChange={(e)=>setpicture(e.target.files[0])} /><br/>
                            </div>

                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link" value={link} onChange={(e)=>setlink(e.target.value)}/>
                            </div>
                         
                            <div>
                                <input type="submit" className="register-button1" value="Submit"/>
                            </div>
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminBooksUpdate
