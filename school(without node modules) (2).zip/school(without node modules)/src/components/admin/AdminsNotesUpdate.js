import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminNotesUpdate() {

    const [params] = useSearchParams();
    const nid = params.get("nid")
    const navigate = useNavigate()

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();

    useEffect(()=>
    {
        if(nid!==null)
        {
            fetchNotes()
        }
    },[nid])

    async function fetchNotes()
    {
        try
        {
            const resp = await axios.get(`http://localhost:8000/api/fetchNotes/${nid}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    const Notes = resp.data.Notesdata;
                    setservice(Notes.service);
                    setsemester(Notes.semester);
                    setsubject(Notes.subject);
                    setsubjectcode(Notes.subjectcode);
                    setlink(Notes.link);
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("Cannot Fetch Notes")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    async function updateNotes(e) 
    {
        e.preventDefault()
        try 
        {
            const updateNotes = { service, semester, subject, subjectcode, link , nid}

            const resp = await axios.put("http://localhost:8000/api/updateNotes" , updateNotes)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Notes Updated Successfully")
                    navigate("/adminNotes");
                }
                else 
                {
                    toast.error("Notes Cannot Updated Successfully. Do some changes for update")
                }
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch (e) 
        {
            alert(e.message)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={updateNotes}>
                        <h1>Edit Notes</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" value={service} required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" value={semester} required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" value={subject} required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" value={subjectcode} required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link"  value={link} onChange={(e)=>setlink(e.target.value)}/>
                            </div>
                         
                         
                            <div>
                                <input type="submit" className="register-button1" value="Submit"/>
                            </div>
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminNotesUpdate
