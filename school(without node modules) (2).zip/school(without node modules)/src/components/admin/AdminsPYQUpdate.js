import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminPYQUpdate() {

    const [params] = useSearchParams();
    const yid = params.get("yid")
    const navigate = useNavigate()

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link1, setlink1] = useState();
    const [link2, setlink2] = useState();
    const [link3, setlink3] = useState();

    useEffect(()=>
    {
        if(yid!==null)
        {
            fetchPYQ()
        }
    },[yid])

    async function fetchPYQ()
    {
        try
        {
            const resp = await axios.get(`http://localhost:8000/api/fetchPYQ/${yid}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    const PYQ = resp.data.pyqdata;
                    setservice(PYQ.service);
                    setsemester(PYQ.semester);
                    setsubject(PYQ.subject);
                    setsubjectcode(PYQ.subjectcode);
                    setlink1(PYQ.link1);
                    setlink2(PYQ.link2);
                    setlink3(PYQ.link3);
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("Cannot Fetch PYQ")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    async function updatePYQ(e) 
    {
        e.preventDefault()
        try 
        {
            const updatePYQ = { service, semester, subject, subjectcode, link1 , link2 ,link3  , yid}

            const resp = await axios.put("http://localhost:8000/api/updatePYQ" , updatePYQ)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Youtube Updated Successfully")
                    navigate("/adminPYQ");
                }
                else 
                {
                    toast.error("PYQ Cannot Updated Successfully. Do some changes for update")
                }
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch (e) 
        {
            alert(e.message)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={updatePYQ}>
                        <h1>Edit PYQ</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" value={service} required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" value={semester} required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" value={subject} required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" value={subjectcode} required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link1">Link1</label>
                                <input type="url" id="link1" name="link1" value={link1} onChange={(e)=>setlink1(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link2">Link2</label>
                                <input type="url" id="link2" name="link2" value={link2} onChange={(e)=>setlink2(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link3">Link3</label>
                                <input type="url" id="link3" name="link3" value={link3} onChange={(e)=>setlink3(e.target.value)}/>
                            </div>
                         
                         
                            <div>
                                <input type="submit" className="register-button1" value="Submit"/>
                            </div>
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminPYQUpdate
