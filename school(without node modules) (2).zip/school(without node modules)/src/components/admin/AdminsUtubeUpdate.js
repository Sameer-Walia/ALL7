import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminUtubeUpdate() {

    const [params] = useSearchParams();
    const uid = params.get("uid")
    const navigate = useNavigate()

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();
   

    useEffect(()=>
    {
        if(uid!==null)
        {
            fetchutube()
        }
    },[uid])

    async function fetchutube()
    {
        try
        {
            const resp = await axios.get(`http://localhost:8000/api/fetchutube/${uid}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    const Utube = resp.data.utubedata;
                    setservice(Utube.service);
                    setsemester(Utube.semester);
                    setsubject(Utube.subject);
                    setsubjectcode(Utube.subjectcode);
                    setlink(Utube.link);
                   
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("Cannot Fetch Youtube")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    async function updateUtube(e) 
    {
        e.preventDefault()
        try 
        {
            const updateUtube = { service, semester, subject, subjectcode, link , uid}

            const resp = await axios.put("http://localhost:8000/api/updateUtube" , updateUtube)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Youtube Updated Successfully")
                    navigate("/adminUtube");
                }
                else 
                {
                    toast.error("Utube Cannot Updated Successfully. Do some changes for update")
                }
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch (e) 
        {
            alert(e.message)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={updateUtube}>
                        <h1>Edit PYQ</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" value={service} required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" value={semester} required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" value={subject} required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" value={subjectcode} required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link" value={link} onChange={(e)=>setlink(e.target.value)}/>
                            </div>
                         
                            <div>
                                <input type="submit" className="register-button1" value="Submit"/>
                            </div>
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminUtubeUpdate
