import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminsyallabusUpdate() {

    const [params] = useSearchParams();
    const sid = params.get("sid")
    const navigate = useNavigate()

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();

    useEffect(()=>
    {
        if(sid!==null)
        {
            fetchsyallabus()
        }
    },[sid])

    async function fetchsyallabus()
    {
        try
        {
            const resp = await axios.get(`http://localhost:8000/api/fetchsyallabus/${sid}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    const syallabus = resp.data.syallabusdata;
                    setservice(syallabus.service);
                    setsemester(syallabus.semester);
                    setsubject(syallabus.subject);
                    setsubjectcode(syallabus.subjectcode);
                    setlink(syallabus.link);
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("Cannot Fetch Syallabus")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }

    async function updatesyallabus(e) 
    {
        e.preventDefault()
        try 
        {
            const updatesyallabus = { service, semester, subject, subjectcode, link , sid}

            const resp = await axios.put("http://localhost:8000/api/updatesyallabus" , updatesyallabus)
            if (resp.status === 200) 
            {
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Syallabus Updated Successfully")
                    navigate("/adminsyallabus");
                }
                else 
                {
                    toast.error("Syallabus Cannot Updated Successfully. Do some changes for update")
                }
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch (e) 
        {
            alert(e.message)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={updatesyallabus}>
                        <h1>Edit Syllabus</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" value={service} required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" value={semester} required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" value={subject} required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" value={subjectcode} required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link" required value={link} onChange={(e)=>setlink(e.target.value)}/>
                            </div>
                         
                         
                            <div>
                                <input type="submit" className="register-button1" value="Submit"/>
                            </div>
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminsyallabusUpdate
