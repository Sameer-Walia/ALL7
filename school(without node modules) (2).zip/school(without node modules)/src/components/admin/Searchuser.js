import React, { useContext, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope } from '@fortawesome/free-solid-svg-icons'
import { userContext } from '../../App'
import axios from 'axios'
import { toast } from 'react-toastify'

function Searchuser() {

    const[email , setemail] = useState()
    const[udata , setudata] = useState()
    const[flag , setflag] = useState()

    async function searchuser(e)
    {
        e.preventDefault()
        try
        {
            const resp = await axios.get(`http://localhost:8000/api/searchuser?email=${email}`)
            // const resp = await axios.get("http://localhost:9000/api/searchuser?email="+email)
            if(resp.status===200)
            {
                if(resp.data.statuscode===0)
                {
                    toast.warning("Incorrct Email");
                    setflag(false)
                }
                else if(resp.data.statuscode===1)
                {
                    setudata(resp.data.userdata)
                    setflag(true)
                }
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error(e.message)
        }

    }



    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div className="text-center mt-5">

                    <h1 class="register-form-title ">Search User</h1>

                    <form onSubmit={searchuser} class="register-form1  ">

                        <div class="input-container mt-3 ">

                            <input type="email" name="useremail" placeholder=""  class="input-field" required onChange={(e)=>setemail(e.target.value)}/>

                            <label class="input-label">
                                <span><FontAwesomeIcon icon={faEnvelope} /></span><span>Email</span>
                            </label>

                        </div>

                        <input type="submit" className="register-button" value="Search" />
                        {
                            flag===true?
                            <div className='login-form-grids'>
                                <b>Name:-</b>{udata.name}<br/>
                                <b>Phone:-</b>{udata.phone}<br/>
                                <b>Email:-</b>{udata.email}<br/>
                                <b>Roll NO:-</b>{udata.rollno}<br/>
                                <b>Semester:-</b>{udata.semester}<br/>
                                <b>Department:-</b>{udata.department}<br/>
                            </div>:null
                        }

                    </form>

                </div>

            </div>
        </>
    )
}

export default Searchuser
