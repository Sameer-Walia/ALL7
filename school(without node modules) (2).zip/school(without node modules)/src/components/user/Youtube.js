import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { json, Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import Footer from '../Footer';

function Youtube() {

    const[semutube , setsemutube] = useState([]);
    const [selectedSemester, setSelectedSemester] = useState();
    const [semes, setsemes] = useState();
    const navigate = useNavigate()


    useEffect(()=>
    {
        setsemes(JSON.parse(sessionStorage.getItem("onesem")))
    },[])

    useEffect(() => {
        const storedSemester = parseInt(localStorage.getItem("selectedSemester"));
        if (storedSemester) {
            setSelectedSemester(storedSemester);
        }
    }, []);

    useEffect(()=>
    {
        if(semes)
        {
            // sessionStorage.setItem("onesem"  ,JSON.stringify(semes))
            fetchutube();
        }
    }, [semes])

    const handleTabClick = (semester) => {
        setSelectedSemester(semester);
        localStorage.setItem("selectedSemester", semester);
        // sessionStorage.setItem("onesem"  ,JSON.stringify(semes))
    };

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navigate("/login")
            toast.error("please login to access the page")
        }
    },[])

    async function fetchutube()
    {
        sessionStorage.setItem("onesem"  ,JSON.stringify(semes))
        try
        {
            const resp = await axios.get(`http://localhost:8000/api/fetchuserutube/${semes}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    setsemutube(resp.data.semesterutube);
                }
                else if(resp.data.statuscode===0)
                {
                    setsemutube([]);
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }


    return (
        <>
            <div class="container">
                <div class="content1">
                    <h1 class="title">
                        <span class="title-text">Youtube</span>
                    </h1>
                    <img src={`assets/images/underline.png`} alt="underline" className="underline-img2" />
                </div>

                <p class="description">
                     Explore YouTube channel links to enhance your understanding and master PTU subjects with ease.
                </p>

                <div className="radio-container">
                    <div className="radio-inputs">
                        {
                            [1, 2, 3, 4, 5, 6, 7, 8 ].map((sem) => 
                            <label key={sem} >
                                <input type="radio" name="semester" value={sem} onClick={() => handleTabClick(sem)}  onChange={(e)=>setsemes(e.target.value)}/>
                                <span className={`name ${selectedSemester === sem ? 'activee' : ''}`}>Semester {sem}</span>
                            </label>
                            
                        )}
                    </div>
                </div>

                {/* Dropdown for mobile screens */}
                <div class="dropdown-container">
                    <select class="custom-select"  onChange={(e)=>setsemes(e.target.value)} required>
                        <option value="">Choose Semester</option>
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                    </select>
                </div>

                {
                    semutube.length > 0 ?
                    <>
                    <div class="youtube-container " >

                        {
                            semutube.map((item , index)=>
                               
                                    <div class="youtube-card1 mb-5 mt-lg-5" key={index} data-aos="zoom-out" data-aos-duration="1000" data-aos-delay="100">
                                        <div class="icon-container ">
                                            <img src="assets/images/resource-allocation.svg" alt="source icon" class="source-icon" />
                                        </div>
                                        <p class="semester"><strong>Semester :&nbsp;</strong>{item.semester}</p>
                                        <p class="subject"><strong>Subject :&nbsp;</strong>{item.subject}</p>
                                        <p class="subject-code"><strong>Subject Code :&nbsp;</strong>{item.subjectcode}</p>
                                        <Link to={item.link} target="_blank" class="channel-link"> Youtube Channel </Link>
                                    </div>
                                
                            )
                        }
                    </div>

                    </>:
                    <div class="no-channel-message">
                        <h1>No YouTube channel for this semester at the moment.</h1>
                    </div>

                }
                

            </div>
            
            <Footer/>
        </>
    )
}

export default Youtube
