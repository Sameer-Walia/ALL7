const express = require('express')
const app = express()
const port = 8000
app.use(express.json());

const cors = require('cors')
app.use(cors())

const multer = require('multer')

const fs = require('fs');  // to delete image from folder

let mystorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads');//we will have to create folder in website where images will be saved
  },
  filename: (req, file, cb) => {
    const picname = Date.now() + '-' + file.originalname;//1711956271167-oil3.webp , date in millinano-seconds
    //milliseconds will be added with original filename and name will be stored in picname constiable

    cb(null, picname);
  }
});
let upload = multer({ storage: mystorage })

const bcrypt = require('bcrypt')
const nodemailer = require('nodemailer')
const {v4 : uuidv4} = require('uuid')
require('dotenv').config()

const transporter = nodemailer.createTransport({
    host: "smtp.hostinger.com",
    port: 465,
    secure: true, // true for 465, false for other ports
    auth: {
        user: `${process.env.SMTP_UNAME}`,    
        pass: `${process.env.SMTP_PASS}`
    },
})


const mongoose = require('mongoose');
const { type } = require('os');
const { Sign } = require('crypto');
const { title } = require('process');
mongoose.connect('mongodb://127.0.0.1:27017/schooldb').then(() => console.log('Connected to MongoDB on port ' + port));


const osType = type();
console.log(osType);

const SignupSchema = mongoose.Schema({ name: String, phone: String, email: { type: String, unique: true }, rollno: String, password: String, semester:String , department:String , usertype:String , actstatus: Boolean , token:String}, { versionKey: false })
const SignupModel = mongoose.model("signup", SignupSchema, "signup");// internal name , schema_name , real collection name


app.post("/api/signup", async (req, res) => 
{
    try 
    {
        const acttoken = uuidv4();
        console.log(acttoken)

        const encryp_pass = bcrypt.hashSync(req.body.pass , 10)

        const newrecord = new SignupModel({ name: req.body.name, phone: req.body.phone, email: req.body.email, rollno: req.body.rollno, password: encryp_pass ,department:req.body.dep , semester:req.body.sem , usertype:"normal" , actstatus:false , token:acttoken})
        const result = await newrecord.save();  // it will save the record into real collection

        if (result) 
        {
            const mailOptions = {
                from: 'class@gtbinstitute.com', // transporter username email
                to: req.body.email,             // user's email id
                subject: 'Activation Mail from University.com',
                html: `Dear ${req.body.name}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3001/activateaccount?code=${acttoken}'>Activate Account<a/>`
            };

            transporter.sendMail(mailOptions , (error , info)=>
            {
                if(error)
                {
                    console.log(error);
                    res.send({ statuscode: 2 })
                }
                else
                {
                    console.log("Email sent: "+ info.response);
                    res.send({ statuscode: 1})
                }
            });
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Error while Signing Up , try again" })
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1})
        console.log(e.message)
    }
})

app.put("/api/activateuseraccount",async(req,res)=>
{
  try
  {
    const updateresult = await SignupModel.updateOne({token: req.body.code}, { $set: {actstatus:true}});
    if(updateresult.modifiedCount===1)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
})

app.post("/api/resendmail", async (req, res) => {
  try 
  {
    const { name , email, phone } = req.body;

    const user = await SignupModel.findOne({ email: email, phone: phone });
    if (user===null) 
    {
      res.send({ statuscode: 0, msg: "User not found with given email and phone" });
    }

    const acttoken = user.token;

    const mailOptions = {
      from: 'class@gtbinstitute.com',
      to: email,
      subject: 'Activation Mail from University.com',
      html: `Dear ${name}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3001/activateaccount?code=${acttoken}'>Activate Account<a/>`
    };

    transporter.sendMail(mailOptions, (error, info) => 
    {
      if (error) 
      {
        console.log(error);
        res.send({ statuscode: 2});
      } 
      else 
      {
        console.log("Resend Email sent: " + info.response);
        res.send({ statuscode: 1 });
      }
    });

  } 
  catch (e) 
  {
    res.send({ statuscode: -1 });
    console.log(e.message)
  }
});

app.post("/api/login", async (req, res) => 
{
    try 
    {

        const result = await SignupModel.findOne({ email: req.body.email})
        console.log(result)

        if (result===null) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            if(bcrypt.compareSync(req.body.pass , result.password))
            {
                const respdata = {_id:result._id , name:result.name , phone:result.phone  , email:result.email , usertype:result.usertype , rollno:result.rollno , semester:result.semester , department:result.department , actstatus:result.actstatus }
                res.send({ statuscode: 1  , userdata : respdata })
            }   
            else
            {
                res.send({ statuscode: 0 })
            }
        }
    }
    catch (e) 
    {
        res.send({ statuscode: -1 })
        console.log(e.message)
    }
})

app.put( "/api/changepassword" , async (req ,res)=>
{
    try
    {
        const result = await SignupModel.findOne({email: req.body.uemail })
        console.log(result)
        if(result===null)
        {
            res.send({ statuscode: 0 })
        }
        else
        {
            if(bcrypt.compareSync(req.body.curpass , result.password))
            {
                const encryp_newpass = bcrypt.hashSync(req.body.newpass , 10)
                const updatepass = await SignupModel.updateOne({ email: req.body.uemail }, { $set: { password:encryp_newpass } })
                if (updatepass.modifiedCount === 1) 
                {
                    res.send({ statuscode: 1 })
                }
                else 
                {
                    res.send({ statuscode: 0 })
                }

            }   
            else
            {
                res.send({ statuscode: 0 })
            }
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallusers" , async (req , res)=>
{
    try
    {
        const result = await SignupModel.find()
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1 , usersdata : result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchoneuser/:userid" ,async (req , res)=>
{
    try
    {
        const result = await SignupModel.find({_id:req.params.userid})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, oneuserdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchoneuserdata/:useremail" ,async (req , res)=>
{
    try
    {
        const result = await SignupModel.find({email:req.params.useremail})
        // const result = await SignupModel.find({email:req.query.email})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, oneuserdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})


app.put("/api/updateoneuser" , async (req , res) =>
{
    try
    {
        const updateresult = await SignupModel.updateOne({ _id: req.body.uid }, { $set: { name: req.body.name, phone: req.body.phone, email: req.body.email, rollno: req.body.rollno ,department:req.body.dep , semester:req.body.sem} });

        if (updateresult.modifiedCount === 1) 
        {
          res.send({ statuscode: 1 })
        }
        else 
        {
          res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.put("/api/updateuserprofile" , async (req , res) =>
{
    try
    {
        const updateresult = await SignupModel.updateOne({ email: req.body.uemail }, { $set: { name: req.body.name, phone: req.body.phone, rollno: req.body.rollno ,department:req.body.dep , semester:req.body.sem} });

        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})


app.delete("/api/deluser", async(req ,res)=>
{
    try
    {
        const result = await SignupModel.deleteOne({_id:req.query.id})
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchcontactdata" ,async (req , res)=>
{
    try
    {
        const result = await SignupModel.find({email:req.query.email})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, usercontactdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/searchuser" ,async (req , res)=>
{
    try
    {
        const result = await SignupModel.find({email:req.query.email})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, userdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

const ContactSchema = mongoose.Schema({name:String , email:String , Subject:String , message:String},{ versionKey: false })
const ContactModel = mongoose.model("contact" , ContactSchema , "contact");

app.post("/api/contact" , async (req , res)=>
{
    try
    {
        const mailOptions = {
        from: 'class@gtbinstitute.com', // transporter username email
        to: 'sameerwalia13@gmail.com',  // any email id of admin where u want to send email
        replyTo: req.body.email,
        subject: 'Message from website - Contact Us Page',
        html: `<b>Name:- </b>${req.body.name}<br/><b>Email:- </b>${req.body.email}<br/><b>Subject:- </b>${req.body.subject}<br/><b>Message:- </b>${req.body.message}`
        };

        transporter.sendMail(mailOptions , (error , info)=>
        {
            if(error)
            {
                console.log(error);
                res.send({ statuscode: 0 })
            }
            else
            {
                console.log("Email sent: "+ info.response);
                res.send({ statuscode: 1 })
            }
        });

    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallcontacts" ,async (req ,res)=>
{
    try
    {
        const result = await ContactModel.find();
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, contactdata: result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.delete("/api/delcontact", async (req, res) =>
{
    try
    {
        const result = await ContactModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Contact deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Contact not deleted" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

const ComplaintSchema = mongoose.Schema({name:String , email:String , department:String ,semester:String , rollno :String ,date:String , message:String},{ versionKey: false })
const ComplaintModel = mongoose.model("complaint" , ComplaintSchema , "complaint");

app.post("/api/complaint" , async (req , res)=>
{
    try
    {
        const newcomplaint = new ComplaintModel({name:req.body.name , email:req.body.email , department:req.body.dep, semester:req.body.sem , rollno:req.body.rollno , date:req.body.currentDate ,  message:req.body.message })
        const result = await newcomplaint.save();

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Complaint Not Submitted" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchcomplaint" , async (req , res)=>
{
    try
    {
        const result = await ComplaintModel.find();

        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, complaintdata: result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delcomplaint", async (req, res) =>
{
    try
    {
        const result = await ComplaintModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Complaint deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Complaint not deleted" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})


const SyallabusSchema = mongoose.Schema({service:String , semester:String , subject:String , subjectcode:String , link:String } ,{ versionKey: false })
const SyallabusModel = mongoose.model("syallabus" , SyallabusSchema , "syallabus");

app.post("/api/addsyallabus" , async (req , res)=>
{
    try
    {
        const addsyallabus = new SyallabusModel({service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link:req.body.link })
        const result = await addsyallabus.save();

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Syallabus Not Added" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallsyallabus" , async (req , res)=>
{
    try
    {
        const result = await SyallabusModel.find();

        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, syallabusdata:result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delsyallabus", async (req, res) =>
{
    try
    {
        const result = await SyallabusModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Syallabus deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Syallabus not deleted" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchsyallabus/:sid" ,async (req , res)=>
{
    try
    {
        const result = await SyallabusModel.find({_id:req.params.sid})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, syallabusdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.put("/api/updatesyallabus" , async (req , res) =>
{
    try
    {
        const updateresult = await SyallabusModel.updateOne({ _id: req.body.sid } , { $set: {service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link:req.body.link }})

        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

const NotesSchema = mongoose.Schema({service:String , semester:Number, subject:String , subjectcode:String , link:String } ,{ versionKey: false })
const NotesModel = mongoose.model("Notes" , NotesSchema , "Notes");

app.post("/api/addNotes" , async (req , res)=>
{
    try
    {
        const addNotes = new NotesModel({service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link:req.body.link })
        const result = await addNotes.save();

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Notes Not Added" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallNotes" , async (req , res)=>
{
    try
    {
        const result = await NotesModel.find();

        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, Notesdata:result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delNotes", async (req, res) =>
{
    try
    {
        const result = await NotesModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Notes deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Notes not deleted" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchNotes/:nid" ,async (req , res)=>
{
    try
    {
        const result = await NotesModel.find({_id:req.params.nid})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, Notesdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.put("/api/updateNotes" , async (req , res) =>
{
    try
    {
        const updateresult = await NotesModel.updateOne({ _id: req.body.nid } , { $set: {service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link:req.body.link }})

        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

const PYQSchema = mongoose.Schema({service:String , semester:String , subject:String , subjectcode:String , link1:String , link2:String , link3:String } ,{ versionKey: false })
const PYQModel = mongoose.model("PYQ" , PYQSchema , "PYQ");

app.post("/api/addPYQ" , async (req , res)=>
{
    try
    {
        const addPYQ = new PYQModel({service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link1:req.body.link1 , link2:req.body.link2 , link3:req.body.link3 })
        const result = await addPYQ.save();

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "PYQ Not Added" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallPYQ" , async (req , res)=>
{
    try
    {
        const result = await PYQModel.find();

        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, PYQdata:result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delPYQ", async (req, res) =>
{
    try
    {
        const result = await PYQModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "PYQ deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "PYQ not deleted" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchPYQ/:qid" ,async (req , res)=>
{
    try
    {
        const result = await PYQModel.find({_id:req.params.qid})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, pyqdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.put("/api/updatePYQ" , async (req , res) =>
{
    try
    {
        const updateresult = await  PYQModel.updateOne({ _id: req.body.yid } , { $set: {service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link1:req.body.link1 , link2:req.body.link2 , link3:req.body.link3  }})

        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

const UtubeSchema = mongoose.Schema({service:String , semester:String , subject:String , subjectcode:String , link:String } ,{ versionKey: false })
const UtubeModel = mongoose.model("Utube" , UtubeSchema , "Utube");

app.post("/api/addUtube" , async (req , res)=>
{
    try
    {
        const addutube = new UtubeModel({service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link:req.body.link })
        const result = await addutube.save();

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Youtube Not Added" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallutube" , async (req , res)=>
{
    try
    {
        const result = await UtubeModel.find();

        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, utubedata:result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delutube", async (req, res) =>
{
    try
    {
        const result = await UtubeModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Youtube deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Youtube not deleted" })
        }
    }
    catch(e)
    {
        res.send({statuscode:-1,errmsg:e.message})
    }
})
app.get("/api/fetchutube/:qid" ,async (req , res)=>
{
    try
    {
        const result = await UtubeModel.find({_id:req.params.qid})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, utubedata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode:-1 , err:e.message})
    }
})
app.put("/api/updateUtube" , async (req , res) =>
{
    try
    {
        const updateresult = await  UtubeModel.updateOne({ _id: req.body.uid } , { $set: {service:req.body.service, semester:req.body.semester , subject:req.body.subject, subjectcode:req.body.subjectcode , link:req.body.link }})

        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode:-1 , err:e.message})
    }
})



const BooksSchema = mongoose.Schema({service:String , semester:Number , subject:String , subjectcode:String , Picture: String, link:String } ,{ versionKey: false })
const BooksModel = mongoose.model("Books" , BooksSchema , "Books");

app.post("/api/addBook" , upload.single('pictures') , async (req , res)=>
{
    try
    {
        var picturename;
        if (!req.file) 
        {
          picturename = "noimage.jpg";
        }
        else 
        {
          picturename = req.file.filename;
        }

        const addbooks = new BooksModel({service:req.body.services, semester:req.body.semesters , subject:req.body.subjects, subjectcode:req.body.subjectcodes , Picture:picturename , link:req.body.links })
        const result = await addbooks.save();

        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Book Not Added" })
        }
    }
    catch(e)
    {
       res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallBooks" , async (req , res)=>
{
    try
    {
        const result = await BooksModel.find();

        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, booksdata:result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delbook", async (req, res) =>
{
    try
    {
        const result = await BooksModel.deleteOne({ _id: req.query.id })
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchbook/:kid" ,async (req , res)=>
{
    try
    {
        const result = await BooksModel.find({_id:req.params.kid})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, bookdata: result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.put("/api/updateBook" , upload.single('uppic'), async (req , res) =>
{
    try
    {
        var picturename;
        if (!req.file) 
        {
            picturename = req.body.oldpicname;//it will save current picname in this constiable
        }
        else 
        {
            picturename = req.file.filename;

            if (req.body.oldpicname !== "noimage.jpg") 
            {
                fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
            }
        }

        const updateresult = await BooksModel.updateOne({ _id: req.body.bookid } , { $set: {service:req.body.services, semester:req.body.semesters , subject:req.body.subjects, subjectcode:req.body.subjectcodes ,Picture:picturename , link:req.body.links }})
        if (updateresult.modifiedCount === 1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

// user

app.get("/api/fetchuserpyq/:semesterPYQ" ,async (req , res)=>
{
    try
    {
        const result = await PYQModel.find({semester:req.params.semesterPYQ})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, semesterpyq: result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchusersyllabus/:semesterSyllabus" ,async (req , res)=>
{
    try
    {
        const result = await SyallabusModel.find({semester:req.params.semesterSyllabus})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, semestersyllabus: result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchuserbook/:semesterbook" ,async (req , res)=>
{
    try
    {
        const result = await BooksModel.find({semester:req.params.semesterbook})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, semesterbook: result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchuserutube/:semesterutube" ,async (req , res)=>
{
    try
    {
        const result = await UtubeModel.find({semester:req.params.semesterutube})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, semesterutube: result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.get("/api/fetchusernotes/:semesternotes" ,async (req , res)=>
{
    try
    {
        const result = await NotesModel.find({semester:req.params.semesternotes})
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1, semesternotes: result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

const BlogSchema = mongoose.Schema({name:String , email:String , title:String , content:String , date:String} , { versionKey: false })
const BlogModel = mongoose.model("blogs" , BlogSchema , "blogs")

app.post("/api/addblog" , async (req , res) =>
{
    try
    {
        const addblog= new BlogModel({name:req.body.authorName, email:req.body.email , title:req.body.title , content:req.body.content , date:req.body.currentDate })
        const result = await addblog.save();
        if (result) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Blog Not Added" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchallblogs" , async (req , res)=>
{
    try
    {
        const result = await BlogModel.find();
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1 , blogsdata : result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.delete("/api/delblog" , async (req , res)=>
{
    try
    {
        const result = await BlogModel.deleteOne({_id:req.query.id});
        if (result.deletedCount === 1) 
        {
            res.send({ statuscode: 1, msg: "Blog deleted successfully" })
        }
        else 
        {
            res.send({ statuscode: 0, msg: "Blog not deleted" })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchoneblog" , async (req , res)=>
{
    try
    {
        const result = await BlogModel.find({_id:req.query.blogid});
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1 , oneblogdata : result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchmyblogs" , async (req , res)=>
{
    try
    {
        const result = await BlogModel.find({email:req.query.email});
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1 , myblogsdata : result })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})

app.get("/api/fetchuniqueblog" , async (req , res)=>
{
    try
    {
        const result = await BlogModel.find({_id:req.query.blogid});
        if (result.length === 0) 
        {
            res.send({ statuscode: 0 })
        }
        else 
        {
            res.send({ statuscode: 1 , oneblogdata : result[0] })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})
app.put("/api/updateblog" , async (req , res)=>
{
    try
    {
        const result = await BlogModel.updateOne({_id:req.body.blogid} , { $set: {title:req.body.title , content:req.body.strippedContent , date:req.body.currentDate}});
        if (result.modifiedCount===1) 
        {
            res.send({ statuscode: 1 })
        }
        else 
        {
            res.send({ statuscode: 0 })
        }
    }
    catch(e)
    {
        res.send({statuscode: -1 })
        console.log(e.message)
    }
})


app.listen(port, () => {
    console.log(`Server is running on port ${port}`)
})


