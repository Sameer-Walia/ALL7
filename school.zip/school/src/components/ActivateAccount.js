import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { toast } from "react-toastify";

function ActivateAccount() {

    const[msg , setmsg] = useState()
    const [params] = useSearchParams();
    const code = params.get("code")
    const navigate = useNavigate()

    useEffect(() => 
    {
        if(code!=="")
        {
            activateuseraccount();
        }
    }, [code])

    useEffect(()=>
    {
        document.title="Activate Account"
    },[])


    async function activateuseraccount() 
    {
        try 
        {
            const apidata = {code}
            const resp = await axios.put(`${process.env.REACT_APP_APIURL}/api/activateuseraccount` , apidata)
           
            if (resp.data.statuscode === 1) 
            {
                toast.success("Account Activated Successfully , please login now");
                navigate("/login")
            }
            else if (resp.data.statuscode === 0) 
            {
                setmsg("Error while activating Account. May be u have already activated. U can directly Login now")
            }
            else 
            {
                toast.warn("Some error occured")
            }
        }
        catch (e) 
        {
            toast.warn("Error Occured " + e.message)
        }
    }

    return (
        <>
            <div className="thanks-page">
                <div className="thanks-container">
                    <div className="thanks-content">
                    <h2 className="thanks-heading">
                        {msg}
                    </h2>
                    </div>
                </div>
            </div>
        </>
    )
}
export default ActivateAccount;