import React, { useContext, useEffect, useState } from 'react'
import { FaUser, FaHome, FaBookOpen, FaYoutube, FaClipboardList, FaBlogger } from "react-icons/fa";
import { RiContactsBookFill } from 'react-icons/ri';

import { Link, useNavigate } from 'react-router-dom';
import Footer from './Footer';
import { userContext } from '../App';


function Adminpanel() {

    const [activeTab, setactiveTab] = useState("Users");
    const navi = useNavigate()

    useEffect(() => {
      const savedActiveLink = localStorage.getItem("tabLink");
      if (savedActiveLink) {
        setactiveTab(savedActiveLink);
      }
    }, []);

    useEffect(()=>
    {
        document.title="Admin Panel"
    },[])

    function handleTabClick(tabname) {
        setactiveTab(tabname);
        localStorage.setItem("tabLink", tabname);
    };

    const{udata } = useContext(userContext)

    function page(e)
    {
        e.preventDefault()
        const user = udata.usertype
        if(user==="admin")
        {
            navi("/adminhome")
        }
        else
        {
            navi("/")
        }
                                        // both are correct
        // const user = JSON.parse(sessionStorage.getItem("userdata"))
        // if(user.usertype ==="admin")
        // {
        //     navi("/adminhome")
        // }
        // else
        // {
        //     navi("/")
        // }
    }

    return (
        <>
            <aside class="sidebar">
                <br />

                <div class="admin-panel">
                    Admin Panel
                </div>

                <nav className="sidebar-nav">
                    <Link to="/adminusers" className={`sidebar-link , ${activeTab === "user" ? "active" : ""}`} onClick={() => handleTabClick("user")}><span className="sidebar-icon">{<FaUser />}</span>Users</Link>

                    <Link to="/admincontact" className={`sidebar-link , ${activeTab === "contact" ? "active" : ""}`} onClick={() => handleTabClick("contact")}><span className="sidebar-icon">{<FaClipboardList />}</span>Contact</Link>

                    <Link to="/adminsyallabus" className={`sidebar-link , ${activeTab === "Syallabus" ? "active" : ""}`} onClick={() => handleTabClick("Syallabus")}><span className="sidebar-icon">{<RiContactsBookFill />}</span>Syallabus</Link>

                    <Link to="/adminnotes" className={`sidebar-link , ${activeTab === "Notes" ? "active" : ""}`} onClick={() => handleTabClick("Notes")}><span className="sidebar-icon">{<FaClipboardList />}</span>Notes</Link>

                    <Link to="/adminpyq" className={`sidebar-link , ${activeTab === "pyq" ? "active" : ""}`} onClick={() => handleTabClick("pyq")}><span className="sidebar-icon">{<FaBookOpen />}</span>Previous Year Questions</Link>

                    <Link to="/adminutube" className={`sidebar-link , ${activeTab === "Youtube" ? "active" : ""}`} onClick={() => handleTabClick("Youtube")}><span className="sidebar-icon">{<FaYoutube />}</span>Youtube</Link>

                    <Link to="/adminbooks" className={`sidebar-link , ${activeTab === "Books" ? "active" : ""}`} onClick={() => handleTabClick("Books")}><span className="sidebar-icon">{<FaBookOpen />}</span>Books</Link>

                    <Link to="/adminblogs" className={`sidebar-link , ${activeTab === "Blogs" ? "active" : ""}`} onClick={() => handleTabClick("Blogs")}><span className="sidebar-icon">{<FaBlogger />}</span>Blogs</Link>

                    <Link onClick={page} className="sidebar-link"><span className="sidebar-icon">{<FaHome />}</span>Home</Link>

                </nav>
            </aside>
        </>
    )

}

export default Adminpanel
