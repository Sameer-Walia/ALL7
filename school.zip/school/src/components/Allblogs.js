import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { FaPen } from 'react-icons/fa';
import { FaUser } from 'react-icons/fa';
import { FaCalendarAlt } from 'react-icons/fa';
import { FaRegNewspaper } from 'react-icons/fa';
import axios from 'axios';
import { toast } from 'react-toastify';
import Footer from './Footer';


function Allblogs() {

    const [blogdata, setblogdata] = useState([])
    const navigate = useNavigate();

    useEffect(() => {
        fetchallblogs()
    }, [])

    useEffect(()=>
    {
        document.title="All Blogs"
    },[])

    async function fetchallblogs() 
    {
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchallblogs`)
            
            if (resp.data.statuscode === 1) 
            {
                setblogdata(resp.data.blogsdata)
            }
            else if (resp.data.statuscode === 0) 
            {
                setblogdata([]);
            }
            else 
            {
                toast.error("some problem occured")
            }
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
    }

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navigate("/login")
            toast.error("please login to access the page")
        }
    },[])
    

    return (
        <div>
            <div class="form-header">
                <h1 class="form-title11 mt-3">
                    Latest Blogs
                </h1>
                <img src={`assets/images/underline.png`} alt="underline" class="underline123" />
            </div>

            <div className="flex1111 justify-center  space-x-4">
                <Link to="/composeblog" className="button1111 md-padding">
                    <FaPen /> <span>&nbsp;&nbsp;Compose Blog</span>
                </Link>
                <Link to="/myblogs" className="button1111 md-padding">
                    <FaRegNewspaper /> <span>&nbsp;&nbsp;My Blog</span>
                </Link>
            </div>

            <div className='container '>
                {
                    blogdata.length > 0 ?
                        <>
                            {
                                blogdata.map((item, index) =>
                                    <div key={index} className="blog-card" data-aos="zoom-out" data-aos-duration="1000" data-aos-delay="100">
                                        <div className="blog-header">
                                            <h2 className="blog-title">{item.title}</h2>
                                        </div>
                                        <div className="blog-info">
                                            <div className="author-info">
                                                <FaUser className="author-icon" />
                                                <span className="author-name">{item.name}</span>
                                            </div>
                                            <div className="date-info">
                                                <FaCalendarAlt className="date-icon" />
                                                <span className="date">{ new Date(item.date).toDateString()}</span>
                                            </div>
                                        </div>
                                        <p className="blog-content" dangerouslySetInnerHTML={{ __html: item.content.substring(0, 100) + '...' }} />
                                        <Link to={`/oneblog?blogid=${item._id}`} className="read-more-button">
                                            Read More
                                        </Link>
                                    </div>
                                )
                            }
                        </> : <h2 className='no-user-message'>No Blog Found</h2>
                }
            </div>
            <div className='ssss'></div>
            <Footer/>
        </div>
    )
}

export default Allblogs
