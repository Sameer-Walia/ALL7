import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { FaPen } from 'react-icons/fa';
import { toast } from "react-toastify";
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import Footer from './Footer';
import { userContext } from '../App';
import DOMPurify from 'dompurify';

function BlogCompose() {

    const{udata} = useContext(userContext)
    const navigate = useNavigate();

    const [title, setTitle] = useState();
    const [content, setContent] = useState();
    const [authorName, setAuthorName] = useState();
    const [currentDate, setCurrentDate] = useState();
    const [loading, setloading] = useState(false);

    useEffect(() => {
        const today = new Date();
        const formattedDate = today.toISOString().split('T')[0]; // Format date to YYYY-MM-DD
        
        setCurrentDate(formattedDate);
    }, []);

    useEffect(()=>
    {
        document.title="Compose Blog"
    },[])

    useEffect(()=>
    {
        if(udata)
        {
            setAuthorName(udata.name)
        }
    },[udata])

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navigate("/login")
            toast.error("please login to access the page")
        }
    },[])

    async function submitblog(e)
    {
        e.preventDefault()

        if (!content) 
        {
            toast.error('Content is required!');
        } 
        else 
        {
            const cleanContent = DOMPurify.sanitize(content, {
            USE_PROFILES: { html: true },
            });
            const strippedContent = cleanContent.replace(/<[^>]+>/g, '');
            console.log('Cleaned Content:', strippedContent);

            const blogdata = {title , content:strippedContent , authorName , currentDate , email:udata.email}
            try
            {
                setloading(true)
                const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/addblog` , blogdata)
               
                if(resp.data.statuscode===1)
                {   
                    toast.success("Blog Added Successfully")
                    canceldb();  // not working canceldb function
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warning(resp.data.msg)
                }
                else
                {
                    toast.warn("some problem occured")
                }
            }
            catch(e)
            {
                toast.error("Error Occured " + e.message)
            }
            finally
            {
                setloading(false)
            }
        }
    }

    function canceldb()
    {  
        setTitle('');
        setContent('');
    }
    
    return (
        <>
            <section className="inner-banner py-5">
                <div className="w3l-breadcrumb py-lg-5">
                    <div className="container pt-4 pb-sm-4">
                        <h4 className="inner-text-title pt-5">Blog</h4>
                        <ul className="breadcrumbs-custom-path">
                            <Link to="/">Home</Link>
                            <li className="active"><i className="fas fa-angle-right"></i>Blog</li>
                        </ul>
                    </div>
                </div>
            </section>
            <div class="container " style={{ marginTop: '70px', backgroundColor: '#fbfbfb;' , marginBottom:'90px'}}>
                <div class="form-wrapper ">
                    <div class="form-header">
                        <h1 class="form-title">
                            <FaPen /> New Blog
                        </h1>
                        <img src={`assets/images/underline.png`} alt="underline" class="underline" />
                    </div>

                    <form onSubmit={submitblog}>
                        <input
                            type="text"
                            onChange={(e) => setAuthorName(e.target.value)}
                            class="input-field11 "
                            placeholder="Author Name"
                            required
                            value={authorName}
                            readOnly
                        />

                        <input
                            type="text"
                            onChange={(e) => setTitle(e.target.value)}
                            class="input-field11 mt-3 mb-3"
                            placeholder="Title"
                            required
                        />

                        <ReactQuill
                            onChange={setContent}
                            class="text-editor"
                            placeholder="Write Blog!"
                            theme="snow"
                            style={{ height: '250px' }} 
                            modules={{
                                toolbar: [
                                    [{ 'header': '1' }, { 'header': '2' }, { 'font': [] }],
                                    [{ size: [] }],
                                    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                                    [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                                    [{ 'align': [] }],
                                    ['clean']
                                ],
                            }}
                        />
                       
                        {
                            loading? 
                            <div className="loader-container">
                                <img src="assets/images/loader.gif" alt="loader" className="loader" />
                            </div>:
                             <button type="submit" class="submit-button">
                                Submit
                            </button>
                        }
                    </form>
                </div>
            </div>
            <Footer/>
        </>
    )
}

export default BlogCompose
