import React, { useContext, useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { userContext } from '../App';
import axios from 'axios';
import { toast } from 'react-toastify';
import ReactQuill from 'react-quill';
import { FaPen } from 'react-icons/fa';
import DOMPurify from 'dompurify';

function BlogUpdate() {

    const [params] = useSearchParams();
    const blogid = params.get("id")

    const{udata} = useContext(userContext)
    const navi = useNavigate();

    const [title, setTitle] = useState();
    const [content, setContent] = useState();
    const [authorName, setAuthorName] = useState();
    const [currentDate, setCurrentDate] = useState();
    const [loading, setloading] = useState(false);

    useEffect(()=>
    {
        document.title="Update Blog"
    },[])

    useEffect(()=>
    {
        if(blogid)
        {
            fetchoneblog();
        }
    },[blogid])

    useEffect(() => {
        const today = new Date();
        const formattedDate = today.toISOString().split('T')[0]; // Format date to YYYY-MM-DD
        
        setCurrentDate(formattedDate);
    }, []);

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
    },[])

    async function fetchoneblog()
    {
        try
        {
            // const email = udata.email
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchuniqueblog?blogid=${blogid}`)
            // const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchuniqueblog?blogid=`+blogid)
            // const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchoneuserdata/${blogid}`)

            
            if (resp.data.statuscode === 1) 
            {
                const data = resp.data.oneblogdata
                setTitle(data.title)
                setAuthorName(data.name)
                setContent(data.content)
            }
            else if (resp.data.statuscode === 0) 
            {
                toast.error("Cannot Fetch Your Blog")
            }
            else 
            {
                toast.error("some problem occured")
            }
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
    }   

    async function updateblog(e)
    {
        e.preventDefault()
        if (!content) 
        {
            toast.error('Content is required!');
        } 
        else
        {
            const cleanContent = DOMPurify.sanitize(content, {
            USE_PROFILES: { html: true },
            });
            const strippedContent = cleanContent.replace(/<[^>]+>/g, '');
            console.log('Cleaned Content:', strippedContent);

            try
            {
                setloading(true)
                const blogdata = {title , strippedContent , currentDate , blogid}
                const resp = await axios.put(`${process.env.REACT_APP_APIURL}/api/updateblog` ,blogdata)
               
                if (resp.data.statuscode === 1) 
                {
                    toast.success("Blog Updated Successfully")
                    navi("/myblogs")
                }
                else if (resp.data.statuscode === 0) 
                {
                    toast.error("Cannot Update Your Blog")
                }
                else 
                {
                    toast.error("some problem occured")
                }
            }
            catch (e) 
            {
                toast.error("Error Occured " + e.message)
            }
            finally
            {
                setloading(false)
            }
        }
    }

  return (
    <div>
        <div class="container " style={{ marginTop: '70px', backgroundColor: '#fbfbfb;' , marginBottom:'90px'}}>
                <div class="form-wrapper ">
                    <div class="form-header">
                        <h1 class="form-title">
                            <FaPen /> Update Blog
                        </h1>
                        <img src={`assets/images/underline.png`} alt="underline" class="underline" />
                    </div>

                    <form onSubmit={updateblog}>
                        <input
                            type="text"
                            onChange={(e) => setAuthorName(e.target.value)}
                            class="input-field11 "
                            placeholder="Author Name"
                            required
                            value={authorName}
                            readOnly
                        />

                        <input
                            type="text"
                            onChange={(e) => setTitle(e.target.value)}
                            class="input-field11 mt-3 mb-3"
                            placeholder="Title"
                            required
                            value={title}
                        />

                        <ReactQuill
                            onChange={setContent}
                            class="text-editor"
                            placeholder="Write Blog!"
                            theme="snow"
                            style={{ height: '250px' }} 
                            value={content}
                            modules={{
                                toolbar: [
                                    [{ 'header': '1' }, { 'header': '2' }, { 'font': [] }],
                                    [{ size: [] }],
                                    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                                    [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                                    [{ 'align': [] }],
                                    ['clean']
                                ],
                            }}
                        />
                        
                        {
                            loading? 
                            <div className="loader-container">
                                <img src="assets/images/loader.gif" alt="loader" className="loader" />
                            </div>:
                            <button type="submit" class="submit-button">
                                Submit
                            </button>
                        }
                    </form>
                </div>
            </div>

    </div>
  )
}

export default BlogUpdate
