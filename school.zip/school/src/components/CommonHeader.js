import { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { userContext } from "../App";

function CommonHeader() {

    const{udata , setudata} = useContext(userContext)
    const navi = useNavigate()

    function logout() 
    {
        setudata(null)
        sessionStorage.clear()
        navi("/")
    }

    function selectpage(e)
    {
        e.preventDefault()
        // const user = udata.usertype
        // if(user==="admin")
        // {
        //     navi("/adminhome")
        // }
        // else
        // {
        //     navi("/")
        // }
                            // both are correct
                            
        const user = JSON.parse(sessionStorage.getItem("userdata"))
        if(user.usertype ==="admin")
        {
            navi("/adminhome")
        }
        else
        {
            navi("/")
        }
    }

    const handleTabClick = (semester) => {
        localStorage.setItem("selectedSemester", semester);
        sessionStorage.setItem("onesem"  ,JSON.stringify(semester))
    };

    return (
        <>
            <header id="site-header" className="fixed-top">
        <div className="container">
            <nav className="navbar navbar-expand-lg navbar-light">
                <Link onClick={selectpage} className="navbar-brand" aria-current="page">
                    <i className="fas fa-graduation-cap"></i> Edu School
                </Link>
                <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarScroll">
                    <ul className="navbar-nav ms-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li className="nav-item mg">
                             <Link to="/about" >About Us</Link>
                        </li>
                        <li class="nav-item mg dropdownsam1">
                            <Link  role="button">Resources</Link>
                            <ol class="dropdown-menu dropdownsam">
                                <li><Link to="/userpyq" class="dropdown-item" onClick={() => handleTabClick("1")} >PYQ</Link></li>
                                <li><Link to="/usersyllabus" class="dropdown-item" onClick={() => handleTabClick("1")} >Syllabus</Link></li>
                                <li><Link to="/userbook" class="dropdown-item" onClick={() => handleTabClick("1")} >Book</Link></li>
                                <li><Link to="/userutube" class="dropdown-item" onClick={() => handleTabClick("1")} >Youtube</Link></li>
                                <li><Link to="/usernotes" class="dropdown-item" onClick={() => handleTabClick("1")} >Notes</Link></li>
                            </ol>
                        </li>

                        <li className="nav-item mg dropdownsam1">
                             <Link to="/allblog" >Blogs</Link>
                             <ol class="dropdown-menu dropdownsam">
                                <li><Link to="/predict" class="dropdown-item">Predict</Link></li>
                            </ol>
                        </li>

                        <li className="nav-item mg">
                             <Link to="/complaint" >Complaint</Link>
                        </li>
                       
                        <li className="nav-item mg">
                             <Link to="/contact" >Contact</Link>
                        </li>
                        <li className="nav-item sam2 mg">
                             <Link to="/userdashboard" >DashBoard</Link>
                        </li>

                        <li className="nav-item sam mg">
                            <Link to="/changepassword" className="cp" style={{ border: '2px solid var(--primary-color)', padding: '10px', borderRadius: 20 }} aria-current="page">Change Password</Link>
                        </li>

                        <li className="nav-item sam ">
                            <button type="button" style={{ border: '2px solid var(--primary-color)', padding: '10px', borderRadius: 20 }} aria-current="page" onClick={logout}>Log-Out</button >
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>

        </>
    )
}
export default CommonHeader;