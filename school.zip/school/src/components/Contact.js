import axios from 'axios'
import React, { useContext, useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import Footer from './Footer';
import { userContext } from '../App';
import { useNavigate } from 'react-router-dom';


function Contact() {

    const[name , setname] = useState()
    const[email , setemail] = useState()
    const[subject , setsubject] = useState()
    const[message , setmessage] = useState()
    const[loading , setloading] = useState(false)
    const{udata} = useContext(userContext)
    const navigate = useNavigate();

    // useEffect(()=>
    // {
    //     if(udata!==null)
    //     {   
    //         setname(udata.name);
    //         setemail(udata.email);
    //     }
    // },[udata])

                // both upper and lower code are correct to fetch data from compass to inputs

    useEffect(()=>
    {
        if(udata)
        {   
            fetchdata()
        }
    },[udata])

    useEffect(() => {
        document.title = "Contact Us";
    }, []);

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navigate("/login")
            toast.error("please login to access the page")
        }
    },[])

    async function fetchdata()
    {
        const email = udata.email
        try
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchcontactdata?email=`+email)
           
            if(resp.data.statuscode===1)
            {
                const usercontact = resp.data.usercontactdata
                setname(usercontact.name);
                setemail(usercontact.email);
            }
            else if(resp.data.statuscode===0)
            {
                toast.error("Cannot Fetch User Data")
            }
            else
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }

    }

    async function oncontact(e)
    {
        e.preventDefault()
        const data = {name , email , subject , message}
        try
        {
            setloading(true)
            const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/contact` , data)
           
            if(resp.data.statuscode===1)
            {
                toast.success("Message submitted successfully. We will revert back in 24 hours")  
                canceldb();
            }
            else if(resp.data.statuscode===0)
            {
                toast.warning(resp.data.msg)
            }
            else
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }

    function canceldb()
    {
        setsubject("")
        setmessage("")
    }


  return (
    <>
      <section className="inner-banner py-5">
        <div className="w3l-breadcrumb py-lg-5">
            <div className="container pt-4 pb-sm-4">
                <h4 className="inner-text-title pt-5">Contact Us</h4>
                <ul className="breadcrumbs-custom-path">
                    <li><a href="index.html">Home</a></li>
                    <li className="active"><i className="fas fa-angle-right"></i>Contact Us</li>
                </ul>
            </div>
        </div>
    </section>

    <section className="w3l-contact py-5" id="contact">
        <div className="container py-md-5 py-4">
            <div className="title-main text-center mx-auto mb-md-5 mb-4" style={{ maxWidth: '500px' }}>
                <p className="text-uppercase">Get In Touch</p>
                <h3 className="title-style">Contact Us</h3>
            </div>
            <div className="row contact-block">
                <div className="col-md-7 contact-right">
                    <form  className="signin-form" onSubmit={oncontact}>
                        <div className="input-grids">
    
                            <input type="text" name="w3lName" id="w3lName" placeholder="Your Name"
                                        className="contact-input" value={name} disabled/>

                            <input type="email" name="w3lSender" id="w3lSender" placeholder="Your Email"
                                        className="contact-input" value={email} disabled/>

                            <input type="text" name="w3lSubect" id="w3lSubect" placeholder="Subject"
                                className="contact-input" value={subject} required onChange={(e)=>setsubject(e.target.value)}/>
 
                        </div>
                        <div className="form-input">
                            <textarea name="w3lMessage" id="w3lMessage" placeholder="Type your message here"
                                required value={message} onChange={(e)=>setmessage(e.target.value)}></textarea>
                        </div>
                        {
                            loading? 
                            <div className="loader-container">
                                <img src="assets/images/loader.gif" alt="loader" className="loader" />
                            </div>: 
                            <div className="text-start">
                                <input type="submit" className="btn-style btn-style-3" name="btn" value="Send Message" />
                            </div>
                        }
                    </form>
                </div>
                <div className="col-md-5 ps-lg-5 mt-md-0 mt-5">
                    <div className="contact-left">
                        <div className="cont-details">
                            <div className="d-flex contact-grid">
                                <div className="cont-left text-center me-3">
                                    <i className="fas fa-building"></i>
                                </div>
                                <div className="cont-right">
                                    <h6>Company Address</h6>
                                    <p>Punjab Technical University Kaputhala , Main Campus</p>
                                </div>
                            </div>
                            <div className="d-flex contact-grid mt-4 pt-lg-2">
                                <div className="cont-left text-center me-3">
                                    <i className="fas fa-phone-alt"></i>
                                </div>
                                <div className="cont-right">
                                    <h6>Call Us</h6>
                                    <p><a href="tel:+1(21) 234 4567">+1(21) 112 7368</a></p>
                                </div>
                            </div>
                            <div className="d-flex contact-grid mt-4 pt-lg-2">
                                <div className="cont-left text-center me-3">
                                    <i className="fas fa-envelope-open-text"></i>
                                </div>
                                <div className="cont-right">
                                    <h6>Email Us</h6>
                                    <p><a href="mailto:example@mail.com" className="mail">PTU@mail.com</a></p>
                                </div>
                            </div>
                            <div className="d-flex contact-grid mt-4 pt-lg-2">
                                <div className="cont-left text-center me-3">
                                    <i className="fas fa-headphones-alt"></i>
                                </div>
                                <div className="cont-right">
                                    <h6>Customer Support</h6>
                                    <p><a href="mailto:info@support.com" className="mail">info@support.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div className="map">

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3407.2129670948875!2d75.45146387506254!3d31.353101855387973!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a4f0935f1bf77%3A0x1ce3e77e73cf1830!2sPunjab%20Technical%20University!5e0!3m2!1sen!2sin!4v1728124426151!5m2!1sen!2sin" 
        width="100%" height="400" frameborder="0"  style={{ border: '0px' }} allowfullscreen="">
        </iframe>
    </div>

    <Footer/>
    </>
  )
}

export default Contact
