import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify'
import { FaTrashAlt, FaUser, FaEnvelope, FaCalendarAlt, FaBuilding } from "react-icons/fa";

function HodComplaints() {

    const [complaintdata, setcomplaintdata] = useState([])

    useEffect(() => {
        fetchcomplaints()
    }, [])

    useEffect(()=>
    {
        document.title="All Complaints"
    },[])
    

    async function fetchcomplaints() 
    {
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchcomplaint`)
            
            if (resp.data.statuscode === 1) 
            {
                setcomplaintdata(resp.data.complaintdata)
            }
            else if (resp.data.statuscode === 0) 
            {
                setcomplaintdata([]);
            }
            else 
            {
                toast.error("some problem occured")
            }
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
    }

    async function deletecomplaint(id)
    {
        try
        {
            var pass = window.confirm("Are you sure to Delete")
            if(pass===true)
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delcomplaint?id=${id}`)
               
                if(resp.data.statuscode===1)
                {
                    toast.success(resp.data.msg)
                    fetchcomplaints()
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warn(resp.data.msg)
                }
                else
                {
                    toast.warn("some problem occured")
                }
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }

    return (
        <>
            <header class="custom-header mt-4">
                <div class="custom-container">
                    <h1 class="header-title">HOD Panel</h1>
                    <nav>
                        <ul class="nav-list">
                            <li class="nav-item">
                                <Link to="/complaintHod" class="nav-link" >
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512"  height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span class="link-text">&nbsp;&nbsp;Student Grievances</span>
                                </Link>
                            </li>
                            <li class="nav-item">
                                <Link to="/adminhome" class="nav-link" >
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512"  height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M280.37 148.26L96 300.11V464a16 16 0 0 0 16 16l112.06-.29a16 16 0 0 0 15.92-16V368a16 16 0 0 1 16-16h64a16 16 0 0 1 16 16v95.64a16 16 0 0 0 16 16.05L464 480a16 16 0 0 0 16-16V300L295.67 148.26a12.19 12.19 0 0 0-15.3 0zM571.6 251.47L488 182.56V44.05a12 12 0 0 0-12-12h-56a12 12 0 0 0-12 12v72.61L318.47 43a48 48 0 0 0-61 0L4.34 251.47a12 12 0 0 0-1.6 16.9l25.5 31A12 12 0 0 0 45.15 301l235.22-193.74a12.19 12.19 0 0 1 15.3 0L530.9 301a12 12 0 0 0 16.9-1.6l25.5-31a12 12 0 0 0-1.7-16.93z"></path>
                                    </svg>
                                    <span class="link-text">&nbsp;&nbsp;Home</span>
                                </Link>
                            </li>
                        </ul>
                    </nav>
                </div>
            </header>


            {
                complaintdata.length > 0 ?
                    <>
                        <section className="section-student-grievances">
                            <div className="container-student-grievances">
                                <h1 className="heading-student-grievances">Student Grievances</h1>
                                <div className="card-grievances">
                                    {
                                        complaintdata.map((item , index)=>
                                            <div key={index} className="card-complaint">
                                                        <div className="complaint-details">
                                                            <h2 className="complaint-title">
                                                                <span className="problem-label">Problem :</span>
                                                                <span className="problem-text">{item.message}</span>
                                                            </h2>

                                                            <p className="complaint-info">
                                                                <FaUser className="icon-user" />
                                                                <span>{item.name}</span>
                                                            </p>
                                                            <p className="complaint-info">
                                                                <FaEnvelope className="icon-email" />
                                                                <span>{item.email}</span>
                                                            </p>
                                                            <p className="complaint-info">
                                                                <FaCalendarAlt className="icon-date" />
                                                                <span>{item.date}</span>
                                                            </p>
                                                            <p className="complaint-info">
                                                                <FaBuilding className="icon-department" />
                                                                <span>{item.department}</span>
                                                            </p>

                                                            <button
                                                                onClick={()=>deletecomplaint(item._id)}
                                                                className="button-delete-complaint"
                                                            >
                                                                <FaTrashAlt />
                                                                <span>Delete</span>
                                                            </button>

                                                        </div>
                                                        
                                            </div>
                                        )
                                    }
                                                    
                                </div>
                            </div>
                        </section>

                    </> : <h2 className='text-center con'>No Complaint Found</h2>
            }

        </>
    )
}
export default HodComplaints;
