import React, { useContext, useEffect } from 'react'
import { toast } from 'react-toastify';
import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom"
import { faEnvelope } from '@fortawesome/free-solid-svg-icons'
import { faLock } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Footer from './Footer';
import { userContext } from '../App';


function Login() {


    const [email, setemail] = useState();
    const [pass, setpass] = useState();
    const [loading, setloading] = useState(false);

    const{udata , setudata} = useContext(userContext)

    const navi = useNavigate();

    useEffect(()=>
    {
        document.title="Login"
    },[])
    

    // Set the active link in both state and localStorage
    // function handleSetActiveLink(link){
    //     localStorage.setItem("activeLink", link);
    // };

    async function onlogin(e) {
        e.preventDefault()
        const logindata = { email, pass };
        try 
        {
            setloading(true)
            const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/login`, logindata)
            if (resp.data.statuscode === 0) 
            {
                toast.warn("Incorrect Email/Password")
                cancel();
            }
            else if (resp.data.statuscode === 1) 
            {
                if(resp.data.userdata.actstatus===true)
                {
                    setudata(resp.data.userdata)
                    sessionStorage.setItem("userdata" ,JSON.stringify(resp.data.userdata));
                    if(resp.data.userdata.usertype==="admin")
                    {
                        toast.success("Successfully Login")
                        navi("/adminhome")
                    }
                    else
                    {
                        toast.success("Successfully Login")
                        navi("/")
                    }
                }
                else
                {
                    toast.error("Your account is not activated , please check your email and activate your account")
                }
                
            }
            else
            {
                toast.error("Some error occured try again")
            }
           
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }

    function cancel() {
        setemail("");
        setpass("")
    }



    return (
        <>
            <section className="inner-banner py-5">
                <div className="w3l-breadcrumb py-lg-5">
                    <div className="container pt-4 pb-sm-4">
                        <h4 className="inner-text-title pt-5">Login</h4>
                        <ul className="breadcrumbs-custom-path">
                            <Link to="/" classNameName="nav-link active" aria-current="page">Home</Link>
                            <li className="active"><i className="fas fa-angle-right"></i>Login</li>
                        </ul>
                    </div>
                </div>
            </section>

            

            <div className="container">
                <div className="row mt-5">
                    <div className="col-sm-6 mt-3">
                        <img src={`assets/images/sign.jpg`} alt="" className="img-fluid" />
                    </div>
                    <div className="col-sm-6 text-center mt-5">

                        <h1 class="register-form-title">Login Form</h1>

                        <form onSubmit={onlogin} class="register-form mt-5">

                            <div class="input-container mt-5 ">

                                <input type="email" name="useremail" placeholder="" value={email} onChange={(e)=>setemail(e.target.value)} class="input-field" required />

                                <label class="input-label">
                                    <span><FontAwesomeIcon icon={faEnvelope} /></span><span>Email</span>
                                </label>

                            </div>

                            <div class="input-container mt-4 ">

                                <input type="password" name="userpass" placeholder="" value={pass} onChange={(e)=>setpass(e.target.value)}class="input-field" required />

                                <label class="input-label">
                                    <span><FontAwesomeIcon icon={faLock} /></span><span>Password</span>
                                </label>

                            </div>

                            {
                                loading? 
                                <div className="loader-container">
                                    <img src="assets/images/loader.gif" alt="loader" className="loader" />
                                </div>:<input type="submit" className="register-button" value="Submit"/>
                            }
                            
                            <p className="register-text ">
                                New Here? <Link to="/signup" className="login-link" >Sign Up</Link>
                            </p>

                        </form>

                    </div>
                </div>
            </div>

      <Footer/>

        </>
    )
}

export default Login
