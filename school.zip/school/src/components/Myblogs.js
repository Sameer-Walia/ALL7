import React, { useContext, useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { FaPen } from 'react-icons/fa';
import { FaRegNewspaper } from 'react-icons/fa';
import Footer from './Footer';
import { userContext } from '../App';
import axios from 'axios';
import { toast } from 'react-toastify';
import { FaUser } from 'react-icons/fa';
import { FaCalendarAlt } from 'react-icons/fa';
import { FaEye } from 'react-icons/fa';
import { FaEdit } from 'react-icons/fa';
import { FaTrash } from 'react-icons/fa';

function Myblogs() {

    const{udata} = useContext(userContext)
    const[myblog , setmyblog] = useState([]);
    const navigate = useNavigate();

    useEffect(()=>
    {
        // if(udata)
        // {
            fetchmyblogs();
        // }
    },[])

    useEffect(()=>
    {
        document.title="My Blogs"
    },[])


    async function fetchmyblogs()
    {
        try
        {
            // const email = udata.email
            const userdata = JSON.parse(sessionStorage.getItem("userdata"))
            const email = userdata.email
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchmyblogs?email=${email}`)
           
            if (resp.data.statuscode === 1) 
            {
                setmyblog(resp.data.myblogsdata)
            }
            else if (resp.data.statuscode === 0) 
            {
                setmyblog([]);
            }
            else 
            {
                toast.error("some problem occured")
            }
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
    }

    function viewblog(e,id)
    {
        e.preventDefault();
        navigate("/myoneblog?blogid="+id)
    }

    async function deleteblog(id)
    {
        try
        {
            var pass = window.confirm("Are you sure to Delete the Blog")
            if(pass===true)
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delblog?id=${id}`)
               
                if(resp.data.statuscode===1)
                {
                    toast.success(resp.data.msg)
                    fetchmyblogs();
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warn(resp.data.msg)
                }
                else
                {
                    toast.warn("some problem occured")
                }
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }

    function updateblog(id)
    {
        navigate("/updateblog?id="+id)
    }


  return (
    <div>
        <div>
            <div class="form-header">
                <h1 class="form-title11 mt-3">
                    My Blogs
                </h1>
                <img src={`assets/images/underline.png`} alt="underline" class="underline123" />
            </div>

            <div className="flex1111 justify-center  space-x-4">
                <Link to="/composeblog" className="button1111 md-padding">
                    <FaPen /> <span>&nbsp;&nbsp;Compose Blog</span>
                </Link>
                <Link to="/allblog" className="button1111 md-padding">
                    <FaRegNewspaper /> <span>&nbsp;&nbsp;All Blogs</span>
                </Link>
            </div>

            <div className='container '>
                {
                    myblog.length > 0 ?
                        <>
                            {
                                myblog.map((item, index) =>
                                    <div key={index} className="blog-card" data-aos="zoom-out" data-aos-duration="1000" data-aos-delay="100">
                                        <div className="blog-header">
                                            <h2 className="blog-title">{item.title}</h2>
                                        </div>
                                        <div className="blog-info">
                                            <div className="author-info">
                                                <FaUser className="author-icon" />
                                                <span className="author-name">{item.name}</span>
                                            </div>
                                            <div className="date-info">
                                                <FaCalendarAlt className="date-icon" />
                                                <span className="date">{ new Date(item.date).toDateString()}</span>
                                            </div>
                                        </div>
                                        <p className="blog-content" dangerouslySetInnerHTML={{ __html: item.content.substring(0, 100) + '...' }} />
                                        {/* <Link to={`/myoneblog?blogid=${item._id}`} className="read-more-button">
                                            View
                                        </Link> */}
                                        <div class="button-groupsim">
                                        <button onClick={(event)=>viewblog(event ,item._id)} class="view-buttonsim">
                                            <FaEye className="icon-spacingsim" /> View
                                        </button>
                                        <button onClick={()=>updateblog(item._id)} class="edit-buttonsim">
                                            <FaEdit className="icon-spacingsim" /> Edit
                                        </button>
                                        <button onClick={()=>deleteblog(item._id)} class="delete-buttonsim">
                                            <FaTrash className="icon-spacingsim" /> Delete
                                        </button>
                                        </div>
                                    </div>
                                )
                            }
                        </> : <h2 className='no-user-message'>Please Compose a Blog</h2>
                }
            </div>
            <div className='ssss'></div>
            <Footer/>
        </div>
    </div>
  )
}

export default Myblogs
