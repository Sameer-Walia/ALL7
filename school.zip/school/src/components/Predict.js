import { useEffect, useState } from 'react';
import axios from 'axios';

function Model() {
    const [loading, setloading] = useState(false);
    const [formData, setFormData] = useState({
        G1: '',
        G2: '',
        studytime: '',
        failures: '',
        absences: '',
        goout: '',
        Dalc: '',
        Walc: '',
        health: '',
        schoolsup: ''  // yes or no
    });

    useEffect(()=>
    {
        document.title="Predict"
    },[])

    const [prediction, setPrediction] = useState();

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // formData: a state object that holds form values.
    // setFormData: the function to update that state.
    // { ...formData, ... }: this copies all existing values in the form (using the spread operator).
    // [e.target.name]: this allows dynamic key access — it updates only the field that triggered the change.
    // e.target.value: this is the new value typed by the user.

    async function handleSubmit(e) 
    {
        e.preventDefault();
        try 
        {
            setloading(true)
            const res = await axios.post(`http://localhost:5002/api/predict`, formData);
            setPrediction(res.data.predicted_grade);
        }
        catch (err) 
        {
            console.error('Prediction failed:', err);
        }
        finally
        {
            setloading(false)
        }
    }

    function getGradeLabel(score) {
        if (score <= 9) return "❌ Fail";
        if (score <= 13) return "⚠️ Average";
        if (score <= 16) return "✅ Good";
        return "🌟 Excellent";
    }

    function getGradeTooltip(score) {
        if (score <= 9) return "The student is failing. Extra help is needed.";
        if (score <= 13) return "The student is doing okay, but can improve.";
        if (score <= 16) return "The student is performing well.";
        return "Excellent performance. Keep it up!";    
    }

    return (
        <>
        <form className="form-container-model" onSubmit={handleSubmit}>
            <h2 className="form-title-model">Student Grade Prediction</h2>

            <input className="form-input-model" name="G1" onChange={handleChange} placeholder="MST-1 Marks (0-20)" />
            <input className="form-input-model" name="G2" onChange={handleChange} placeholder="MST-2 Marks (0-20)" />
            <input className="form-input-model" name="studytime" onChange={handleChange} placeholder="Enter weekly study time (1=less than 2 hours to 4=10+ hours)" />
            <input className="form-input-model" name="failures" onChange={handleChange} placeholder="Enter number of past class failures (0-3)" />
            <input className="form-input-model" name="absences" onChange={handleChange} placeholder="Enter number of absences" />
            <input className="form-input-model" name="goout" onChange={handleChange} placeholder="Rate how often student goes out with friends (1=low to 5=high)" />
            <input className="form-input-model" name="Dalc" onChange={handleChange} placeholder="Workday alcohol consumption (1=very low to 5=very high)" />
            <input className="form-input-model" name="Walc" onChange={handleChange} placeholder="Weekend alcohol consumption (1=very low to 5=very high)" />
            <input className="form-input-model" name="health" onChange={handleChange} placeholder="Current health status (1=very bad to 5=very good)" />
            <input className="form-input-model" name="schoolsup" onChange={handleChange} placeholder="Extra classes support? (yes/no)" />

            {
                loading? 
                <div className="loader-container">
                    <img src="assets/images/loader.gif" alt="loader" className="loader" />
                </div>:<button type="submit" className="form-button-model">Predict</button>
            }

            {prediction !== undefined && (
                <div className="form-result1">
                    <p className='pt-3'>🎯 Predicted Final Grade: <strong>{prediction}</strong> / 20</p>
                    <div className={`grade-tag1  tooltip-animate`} title={getGradeTooltip(prediction)}>
                        {/* The title attribute in HTML (and in JSX like React) is used to provide a tooltip — a small popup box that appears when the user hovers over the element. */}
                        {getGradeLabel(prediction)}
                    </div>

                </div>
            )}

        </form>

        <div className="grade-info1 mb-5">
            <h4>📘 Grade Interpretation:</h4>
            <table className="grade-table1">
                <thead>
                    <tr>
                        <th>Grade (Out of 20)</th>
                        <th>Interpretation</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td>0 – 9</td><td>❌ Fail</td></tr>
                    <tr><td>10 – 13</td><td>⚠️ Average</td></tr>
                    <tr><td>14 – 16</td><td>✅ Good</td></tr>
                    <tr><td>17 – 20</td><td>🌟 Excellent</td></tr>
                </tbody>
            </table>
        </div>

        </>

    );
}

export default Model;
