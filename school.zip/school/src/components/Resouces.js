import React, { useContext, useEffect, useState } from 'react'
import { userContext } from '../App';
import { json, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

function Sam({ icon, title, description, link }) 
{

    const { udata } = useContext(userContext)
    const navi = useNavigate();

    function handleExploreClick(e, sem) {
        e.preventDefault();

        if (udata === null) 
        {
            navi("/login")
            toast.warn("Please Login")
        }
        else 
        {
            navi(link);
            sessionStorage.setItem("onesem", JSON.stringify(sem))
            localStorage.setItem("selectedSemester", sem);
        }
    }

    useEffect(()=>
    {
        document.title="Resources"
    },[])

    return (
        <>
            <div class="container mb-3">
                <div className="cardsam" data-aos="zoom-out" data-aos-duration="1000">
                    <div className="icon-container" data-aos="zoom-out" data-aos-duration="1000" data-aos-offset="100">
                        <img src={icon} alt={`${title} Icon`} className="icon" />
                    </div>
                    <h2 className="title" data-aos="zoom-out" data-aos-duration="1000" data-aos-delay="100">{title}</h2>
                    <p className="descriptionsam" data-aos="zoom-out" data-aos-duration="1000" data-aos-delay="100" data-aos-offset="100">{description}</p>
                    <button
                        onClick={(event) => handleExploreClick(event, "1")}
                        className="explore-button"
                        data-aos="zoom-out"
                        data-aos-duration="1000"
                        data-aos-delay="100"
                        data-aos-offset="100"
                    >
                        Explore
                    </button>
                </div>
            </div >
        </>
    )

};

function CardsSection() 
{

    return (
        <div className="container">
            <div class="content1">
                <h1 class="titlesim mt-4">
                    <span>Resources We <span className='highlight'>Offer</span></span>
                </h1>
                <img src={`assets/images/underline.png`} alt="underline" className="underline-imgsam" />
            </div>
            <div className="card-grid">
                <Sam
                    icon={`assets/images/notes.svg`}
                    title="Student Grievances"
                    description="Submit your complaints or issues here. The Head of Department (HOD) will review them, take appropriate action, and work towards resolving them."
                    link="/complaint"
                />
                <Sam
                    icon={`assets/images/edit.svg`}
                    title="Blogs"
                    description="Engage with the community by writing and reading blogs that share insights, tips, and experiences."
                    link="/allblog"
                />
                <Sam
                    icon={`assets/images/books.svg`}
                    title="Previous Year Questions (PYQ)"
                    description="A vast repository of previous year question papers to help you understand exam patterns and prepare effectively."
                    link="/userpyq"
                />
                <Sam
                    icon={`assets/images/work-checklist.svg`}
                    title="Syllabus"
                    description="Stay on track with our comprehensive syllabus guide. Tailored to your curriculum, it’s your roadmap to mastering every subject."
                    link="/usersyllabus"
                />
                <Sam
                    icon={`assets/images/books.svg`}
                    title="Books Available"
                    description="Access a collection of recommended books for each subject to enhance your learning and understanding."
                    link="/userbook"
                />
                <Sam 
                    icon={`assets/images/resource-allocation.svg`}
                    title="Curated YouTube Channels"
                    description="Explore our curated YouTube channels for each subject, where you can access video lectures and tutorials tailored to the syllabus of Punjab Technical University."
                    link="/userutube"
                />
            </div>
        </div>
    )
};

export default CardsSection;
