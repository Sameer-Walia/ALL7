import React, { useContext, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { FaEnvelope, FaPhone, FaEdit, FaUniversity, FaIdBadge, FaListOl } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { userContext } from "../App";
import axios from "axios";
import { toast } from "react-toastify";

function Userdashboard() {
    const navigate = useNavigate();

    const { udata, setudata } = useContext(userContext)

    useEffect(()=>
    {
        document.title="User Dashboard"
    },[])


    const [name, setname] = useState();
    const [phone, setphone] = useState();
    const [email, setemail] = useState();
    const [rollno, setrollno] = useState();
    const [sem, setsem] = useState();
    const [dep, setdep] = useState();
    const [userdata, setuserdata] = useState();

    // useEffect(() => {
    //     if (udata !== null) {
    //         fetchoneuser()
    //     }
    // }, [udata])

    useEffect(() => {
        if (sessionStorage.getItem("userdata")!==null) 
        {
            fetchoneuser()
        }
    }, [])


    async function fetchoneuser() 
    {
        // const uemail = udata.email;
        const userdata = JSON.parse(sessionStorage.getItem("userdata"));
        const uemail = userdata.email

        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchoneuserdata/${uemail}`)
            // const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchoneuserdata?email=`+uemail)
          
            if (resp.data.statuscode === 1) 
            {
                const user = resp.data.oneuserdata;
                setname(user.name);
                setphone(user.phone);
                setemail(user.email);
                setrollno(user.rollno);
                setsem(user.semester);
                setdep(user.department);
            }
            else if (resp.data.statuscode === 0) 
            {
                toast.error("Cannot Fetch User Data. Please Login again")
            }
            else 
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch (e) 
        {
            toast.error("Error Occured " + e.message)
        }
    }

    return (
        <div className="bg-gray-100">
            <div className="container ">
                <div className="card">
                    {/* Left Section */}
                    <div className="left-section">
                        <img src={`assets/images/profile.jpg`} className="profile-img" />
                        <h2 className="text-white ">{name}</h2>
                        <p className="text-white text-base">Student</p>
                        <motion.button
                            className="button"
                            onClick={() => navigate("/updateprofile")}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                        >
                            <h6><FaEdit className="mr-2 " /> Edit Profile</h6>
                        </motion.button>
                    </div>

                    {/* Right Section */}
                    <div className="right-section">
                        <h2 className="text-2xl text-gray-800">Student Data</h2>
                        <div className="grid md-grid-cols-2">
                            <div className="flex items-center">
                                <FaEnvelope className="iconsam"/>
                                <p className="margin">Email</p>
                                <p className="margin1">{email}</p>
                            </div>

                            <div className="flex items-center">
                                <FaPhone className="iconsam" />
                                <p className="margin">Phone</p>
                                <p className="margin1">{phone}</p>
                            </div>

                            <div className="flex items-center">
                                <FaIdBadge className="iconsam" />
                                <p className="margin">University Roll No</p>
                                <p className="margin1">{rollno}</p>
                            </div>
                            
                            <div className="flex items-center">
                                <FaUniversity className="iconsam" />
                                <p className="margin">Department</p>
                                <p className="margin1">{dep}</p>
                            </div>

                            <div className="flex items-center">
                                <FaListOl className="iconsam" />
                                <p className="margin">Semester</p>
                                <p className="margin1">{sem}</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};


export default Userdashboard;
