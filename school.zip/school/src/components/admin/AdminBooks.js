import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminBooks() {

    const [books, setbooks] = useState([])

    useEffect(() => {
        fetchallBooks();
    }, [])

    useEffect(() => {
        document.title = "All Added Books";
    }, []);

    async function fetchallBooks()
    {
        
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchallBooks`)
            if (resp.data.statuscode === 1) 
            {
                setbooks(resp.data.booksdata)
            }
            else if (resp.data.statuscode === 0) 
            {
                setbooks([]);
            }
            else 
            {
                toast.warn("Some Problem Occured , try again")
            }
        }
        catch (err) 
        {
            toast.error("Error Occured " + err.message)
        }
    }

    async function delbooks(id)
    {
        var confirm = window.confirm("Are u sure want to delete the Book")
        if(confirm===true)
        {
            try
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delbook?id=${id}`)
                if(resp.data.statuscode===1)
                {
                    toast.success("Book Deleted Successfully")
                    fetchallBooks();
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("Book not Deleted")
                }
                else 
                {
                    toast.error("Some error occured , try again")
                }
            }
            catch(e)
            {
                toast.error("Error Occured " +  e.message)
            }
        }
    }
    return (
        <>
            <Adminpanel />
            <div className='content'>
                <section className="section">
                    <div className="section-content">
                        <h1 className="section-title">Admin Books Data</h1>
                        <div className="user-count">
                            <Link to="/addbook"><input type='button' className="edit-button2" value="Add New Book" /></Link>
                        </div>
                        {
                            books.length > 0 ?

                                <div className="table-container">
                                    <table width="100%">
                                        <thead>
                                            <tr className="table-header text-center" >
                                                <th className="table-header">Service</th>
                                                <th className="table-header">Semester</th>
                                                <th className="table-header">Image</th>
                                                <th className="table-header">Subject</th>
                                                <th className="table-header">Subject Code</th>
                                                <th className="table-header">Link</th>
                                                <th className="table-header">Edit</th>
                                                <th className="table-header">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                books.map((item, index) =>
                                                    <tr key={index} className="table-row">
                                                        <td className="table-cell">{item.service}</td>
                                                        <td className="table-cell">{item.semester}</td>
                                                        <td className="table-cell"><img src={`uploads/${item.Picture}`} height="60"/></td>
                                                        <td className="table-cell">{item.subject}</td>
                                                        <td className="table-cell">{item.subjectcode}</td>
                                                        <td className="table-cell">
                                                            <Link to={item.link} target="_blank">
                                                                Link 
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <Link to={`/updatebook?bid=${item._id}`} className="edit-button">
                                                                Edit
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <button className="delete-button" onClick={()=>delbooks(item._id)} >
                                                                Delete
                                                            </button>
                                                        </td>
                                                    </tr>
                                                )
                                            }

                                        </tbody>
                                    </table>
                                </div>
                                : <div class="no-user-message">No Book Added</div>
                        }
                    </div>
                </section>
            </div>
        </>
    )
}

export default AdminBooks
