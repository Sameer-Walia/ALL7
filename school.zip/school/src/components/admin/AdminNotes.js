import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminNotes() {

    const [Notesdata, setNotesdata] = useState([])

    useEffect(() => {
        fetchallNotes();
    }, [])

    useEffect(() => {
        document.title = "All Added Notes";
    }, []);
    

    async function fetchallNotes()
    {
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchallNotes`)
            if (resp.data.statuscode === 1) 
            {
                setNotesdata(resp.data.Notesdata)
            }
            else if (resp.data.statuscode === 0) 
            {
                setNotesdata([]);
            }
            else 
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch (err) 
        {
            toast.error("Error Occured " + err.message)
        }
    }

    async function delnotes(id)
    {
        var confirm = window.confirm("Are u sure want to delete the Notes")
        if(confirm===true)
        {
            try
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delNotes?id=${id}`)
                if(resp.data.statuscode===1)
                {
                    toast.success("Notes Deleted Successfully")
                    fetchallNotes();
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warn("Notes not Deleted")
                }
                else 
                {
                    toast.warn("Some Problem Occured")
                }
            }
            catch(e)
            {
                toast.error("Error Occured " + e.message)
            }
        }
    }
    return (
        <>
            <Adminpanel />
            <div className='content'>
                <section className="section">
                    <div className="section-content">
                        <h1 className="section-title">Admin Notes Data</h1>
                        <div className="user-count">
                            <Link to="/addnotes"><input type='button' className="edit-button2" value="Add New Notes" /></Link>
                        </div>
                        {
                            Notesdata.length > 0 ?

                                <div className="table-container">
                                    <table width="100%">
                                        <thead>
                                            <tr className="table-header text-center" >
                                                <th className="table-header">Service</th>
                                                <th className="table-header">Semester</th>
                                                <th className="table-header">Subject</th>
                                                <th className="table-header">Subject Code</th>
                                                <th className="table-header">Link</th>
                                                <th className="table-header">Edit</th>
                                                <th className="table-header">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                Notesdata.map((item, index) =>
                                                    <tr key={index} className="table-row">
                                                        <td className="table-cell">{item.service}</td>
                                                        <td className="table-cell">{item.semester}</td>
                                                        <td className="table-cell">{item.subject}</td>
                                                        <td className="table-cell">{item.subjectcode}</td>
                                                        <td className="table-cell">
                                                            <Link to={item.link} target="_blank" >
                                                                Link
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <Link to={`/updatenotes?nid=${item._id}`} className="edit-button">
                                                                Edit
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <button className="delete-button" onClick={()=>delnotes(item._id)} >
                                                                Delete
                                                            </button>
                                                        </td>
                                                    </tr>
                                                )
                                            }

                                        </tbody>
                                    </table>
                                </div>
                                : <div class="no-user-message">No Notes Added</div>
                        }
                    </div>
                </section>
            </div>
        </>
    )
}

export default AdminNotes
