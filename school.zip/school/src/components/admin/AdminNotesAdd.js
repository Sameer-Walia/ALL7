import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminNotesAdd() {

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();
    const [loading, setloading] = useState(false);

    const navigate = useNavigate();


    useEffect(() => {
        document.title = "Add Notes";
    }, []);
    

    async function submitNotes(e)
    {
        e.preventDefault()
        try
        {
            setloading(true)
            const data = {service , semester, subject, subjectcode , link}

            const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/addNotes` , data)
            
            if (resp.data.statuscode === 1) 
            {
                toast.success("Notes Added Successfully")
                navigate("/adminnotes");
            }
            else if (resp.data.statuscode === 0) 
            {
                toast.error("Notes Cannot added Successfully.")
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch(e)
        {
            toast.warn("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={submitNotes}>
                        <h1>Add New Notes</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject"  required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link" onChange={(e)=>setlink(e.target.value)}/>
                            </div>

                            {
                                loading? 
                                <div className="loader-container">
                                    <img src="assets/images/loader.gif" alt="loader" className="loader" />
                                </div>:
                                <div>
                                    <input type="submit" className="register-button1" value="Submit"/>
                                </div>
                            }
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminNotesAdd
