import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminPYQAdd() {

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link1, setlink1] = useState();
    const [link2, setlink2] = useState();
    const [link3, setlink3] = useState();
    const [loading, setloading] = useState(false);

    const navigate = useNavigate();

    useEffect(() => {
        document.title = "Add PYQs";
    }, []);
    

    async function submitPYQ(e)
    {
        e.preventDefault()
        try
        {
            setloading(true)
            const data = {service , semester, subject, subjectcode , link1 , link2 , link3}

            const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/addPYQ` , data)

            if (resp.data.statuscode === 1) 
            {
                toast.success("PYQ Added Successfully")
                navigate("/adminpyq");
            }
            else if (resp.data.statuscode === 0) 
            {
                toast.error("PYQ Cannot added Successfully.")
            }
            else 
            {
                alert("Some error occured")
            }
        }
        catch(e)
        {
            toast.warn(e.message)
        }
        finally
        {
            setloading(false)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={submitPYQ}>
                        <h1>Add New PYQ</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject"  required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link1">Link1</label>
                                <input type="url" id="link1" name="link1" onChange={(e)=>setlink1(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link2">Link2</label>
                                <input type="url" id="link2" name="link2" onChange={(e)=>setlink2(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link3">Link3</label>
                                <input type="url" id="link3" name="link3" onChange={(e)=>setlink3(e.target.value)}/>
                            </div>
                         
                            {
                                loading? 
                                <div className="loader-container">
                                    <img src="assets/images/loader.gif" alt="loader" className="loader" />
                                </div>:
                                <div>
                                    <input type="submit" className="register-button1" value="Submit"/>
                                </div>
                            }
                       
                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminPYQAdd
