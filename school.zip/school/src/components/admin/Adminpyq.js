import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminPYQ() {

    const [pyq, setpyq] = useState([])

    useEffect(() => {
        fetchallPYQ();
    }, [])

    useEffect(() => {
        document.title = "All Added PYQs";
    }, []);
    

    async function fetchallPYQ()
    {
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchallPYQ`)
            if (resp.data.statuscode === 1) 
            {
                setpyq(resp.data.PYQdata)
            }
            else if (resp.data.statuscode === 0)
            {
                setpyq([]);
            }
            else 
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch (err) 
        {
            toast.error("Error Occured " + err.message)
        }
    }

    async function delpyq(id)
    {
        var confirm = window.confirm("Are u sure want to delete the PYQ")
        if(confirm===true)
        {
            try
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delPYQ?id=${id}`)
                if(resp.data.statuscode===1)
                {
                    toast.success("PYQ Deleted Successfully")
                    fetchallPYQ();
                }
                else if(resp.data.statuscode===0)
                {
                    alert("PYQ not Deleted")
                }
                else 
                {
                    toast.warn("Some Problem Occured")
                }
            }
            catch(e)
            {
                toast.error("Error Occured " + e.message)
            }
        }
    }
    return (
        <>
            <Adminpanel />
            <div className='content'>
                <section className="section">
                    <div className="section-content">
                        <h1 className="section-title">Admin PYQ Data</h1>
                        <div className="user-count">
                            <Link to="/addpyq"><input type='button' className="edit-button2" value="Add New PYQ" /></Link>
                        </div>
                        {
                            pyq.length > 0 ?

                                <div className="table-container">
                                    <table width="100%">
                                        <thead>
                                            <tr className="table-header text-center" >
                                                <th className="table-header">Service</th>
                                                <th className="table-header">Semester</th>
                                                <th className="table-header">Subject</th>
                                                <th className="table-header">Subject Code</th>
                                                <th className="table-header">Link 1</th>
                                                <th className="table-header">Link 2</th>
                                                <th className="table-header">Link 3</th>
                                                <th className="table-header">Edit</th>
                                                <th className="table-header">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                pyq.map((item, index) =>
                                                    <tr key={index} className="table-row">
                                                        <td className="table-cell">{item.service}</td>
                                                        <td className="table-cell">{item.semester}</td>
                                                        <td className="table-cell">{item.subject}</td>
                                                        <td className="table-cell">{item.subjectcode}</td>
                                                        <td className="table-cell">
                                                            <Link to={item.link1} target="_blank" >
                                                                Link 1
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <Link to={item.link2} target="_blank" >
                                                                Link 2
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <Link to={item.link3} target="_blank" >
                                                                Link 3
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <Link to={`/updatepyq?yid=${item._id}`} className="edit-button">
                                                                Edit
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <button className="delete-button" onClick={()=>delpyq(item._id)} >
                                                                Delete
                                                            </button>
                                                        </td>
                                                    </tr>
                                                )
                                            }

                                        </tbody>
                                    </table>
                                </div>
                                : <div class="no-user-message">No PYQ Added</div>
                        }
                    </div>
                </section>
            </div>
        </>
    )
}

export default AdminPYQ
