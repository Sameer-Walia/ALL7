import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function Adminsyallabus() {

    const [syallabusdata, setsyallabusdata] = useState([])

    useEffect(() => {
        fetchallsyallabus();
    }, [])

    useEffect(() => {
        document.title = "All Added Syallabus";
    }, []);
    

    async function fetchallsyallabus()
    {
        try 
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchallsyallabus`)
            if (resp.data.statuscode === 1) 
            {
                setsyallabusdata(resp.data.syallabusdata)
            }
            else if (resp.data.statuscode === 0) 
            {
                setsyallabusdata([]);
            }
            else 
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch (e) 
        {
            toast.warn("Error Occured " + e.message)
        }
    }

    async function deluser(id)
    {
        var confirm = window.confirm("Are u sure want to delete the Syallabus")
        if(confirm===true)
        {
            try
            {
                const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/delsyallabus?id=${id}`)
                if(resp.data.statuscode===1)
                {
                    toast.success("Syallabus Deleted Successfully")
                    fetchallsyallabus();
                }
                else if(resp.data.statuscode===0)
                {
                    alert("Syallabus not Deleted")
                }
                else 
                {
                    toast.warn("Some Problem Occured")
                }
            }
            catch(e)
            {
                toast.warn("Error Occured " + e.message)
            }
        }
    }
    return (
        <>
            <Adminpanel />
            <div className='content'>
                <section className="section">
                    <div className="section-content">
                        <h1 className="section-title">Admin Syallabus Data</h1>
                        <div className="user-count">
                            <Link to="/addsyallabus"><input type='button' className="edit-button2" value="Add New Syallabus" /></Link>
                        </div>
                        {
                            syallabusdata.length > 0 ?

                                <div className="table-container">
                                    <table width="100%">
                                        <thead>
                                            <tr className="table-header text-center" >
                                                <th className="table-header">Service</th>
                                                <th className="table-header">Semester</th>
                                                <th className="table-header">Subject</th>
                                                <th className="table-header">Subject Code</th>
                                                <th className="table-header">Link</th>
                                                <th className="table-header">Edit</th>
                                                <th className="table-header">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                syallabusdata.map((item, index) =>
                                                    <tr key={index} className="table-row">
                                                        <td className="table-cell">{item.service}</td>
                                                        <td className="table-cell">{item.semester}</td>
                                                        <td className="table-cell">{item.subject}</td>
                                                        <td className="table-cell">{item.subjectcode}</td>
                                                        <td className="table-cell">
                                                            <Link to={item.link} target="_blank" >
                                                                Link
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <Link to={`/updatesyallabus?sid=${item._id}`} className="edit-button">
                                                                Edit
                                                            </Link>
                                                        </td>
                                                        <td className="table-cell">
                                                            <button className="delete-button"  onClick={()=>deluser(item._id)} >
                                                                Delete
                                                            </button>
                                                        </td>
                                                    </tr>
                                                )
                                            }

                                        </tbody>
                                    </table>
                                </div>
                                : <div class="no-user-message">No Syallabus Added</div>
                        }
                    </div>
                </section>
            </div>
        </>
    )
}

export default Adminsyallabus
