import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function AdminsyallabusUpdate() {

    const [params] = useSearchParams();
    const sid = params.get("sid")
    const navigate = useNavigate()

    const [service, setservice] = useState();
    const [semester, setsemester] = useState();
    const [subject, setsubject] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [link, setlink] = useState();
    const [loading, setloading] = useState(false);
    

    useEffect(() => {
        document.title = "Update Syallabus";
    }, []);
    

    useEffect(()=>
    {
        if(sid!==null)
        {
            fetchsyallabus()
        }
    },[sid])

    async function fetchsyallabus()
    {
        try
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchsyallabus/${sid}`)
           
            if(resp.data.statuscode===1)
            {
                const syallabus = resp.data.syallabusdata;
                setservice(syallabus.service);
                setsemester(syallabus.semester);
                setsubject(syallabus.subject);
                setsubjectcode(syallabus.subjectcode);
                setlink(syallabus.link);
            }
            else if(resp.data.statuscode===0)
            {
                toast.error("Cannot Fetch Syallabus")
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.warn("Error Occured " + e.message)
        }
    }

    async function updatesyallabus(e) 
    {
        e.preventDefault()
        try 
        {
            setloading(true)
            const updatesyallabus = { service, semester, subject, subjectcode, link , sid}
            const resp = await axios.put(`${process.env.REACT_APP_APIURL}/api/updatesyallabus` , updatesyallabus)
           
            if (resp.data.statuscode === 1) 
            {
                toast.success("Syallabus Updated Successfully")
                navigate("/adminsyallabus");
            }
            else if (resp.data.statuscode === 0) 
            {
                toast.error("Syallabus Cannot Updated Successfully. Do some changes for update")
            }
            else 
            {
                toast.warn("Some error occured")
            }
        }
        catch (e) 
        {
            toast.warn("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }

    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div class="container form-container">
                    <section class="form-section2">
                        <form onSubmit={updatesyallabus}>
                        <h1>Edit Syllabus</h1>
                            <div class="form-group">
                                <label for="service">Service Name</label>
                                <input type="text" id="service"  name="service" value={service} required onChange={(e)=>setservice(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="semester">Semester</label>
                                <input type="text" id="semester" name="semester" value={semester} required onChange={(e)=>setsemester(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" value={subject} required onChange={(e)=>setsubject(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="subjectcode">Subject Code</label>
                                <input type="text" id="subjectcode" name="subjectcode" value={subjectcode} required  onChange={(e)=>setsubjectcode(e.target.value)}/>
                            </div>
                            <div class="form-group">
                                <label for="link">Link</label>
                                <input type="url" id="link" name="link" required value={link} onChange={(e)=>setlink(e.target.value)}/>
                            </div>
                         
                            {
                                loading? 
                                <div className="loader-container">
                                    <img src="assets/images/loader.gif" alt="loader" className="loader" />
                                </div>:
                                <div>
                                    <input type="submit" className="register-button1" value="Submit"/>
                                </div>
                            }
                                                    

                        </form>
                    </section>
                </div>

            </div>
        </>
    )
}

export default AdminsyallabusUpdate
