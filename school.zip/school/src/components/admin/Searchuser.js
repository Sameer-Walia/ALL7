import React, { useContext, useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope } from '@fortawesome/free-solid-svg-icons'
import { userContext } from '../../App'
import axios from 'axios'
import { toast } from 'react-toastify'

function Searchuser() {

    const[email , setemail] = useState()
    const[udata , setudata] = useState()
    const[flag , setflag] = useState()
    const [loading, setloading] = useState(false);

    useEffect(() => {
        document.title = "Search User";
    }, []);
    

    async function searchuser(e)
    {
        e.preventDefault()
        try
        {
            setloading(true)
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/searchuser?email=${email}`)
            // const resp = await axios.get("http://localhost:9000/api/searchuser?email="+email)
           
            if(resp.data.statuscode===0)
            {
                toast.warning("Incorrct Email");
                setflag(false)
            }
            else if(resp.data.statuscode===1)
            {
                setudata(resp.data.userdata)
                setflag(true)
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }
        catch(e)
        {
           toast.warn("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }

    }



    return (
        <>
            <Adminpanel />
            <div className='content'>
                <div className="text-center mt-5">

                    <h1 class="register-form-title ">Search User</h1>

                    <form onSubmit={searchuser} class="register-form1  ">

                        <div class="input-container mt-3 ">

                            <input type="email" name="useremail" placeholder=""  class="input-field" required onChange={(e)=>setemail(e.target.value)}/>

                            <label class="input-label">
                                <span><FontAwesomeIcon icon={faEnvelope} /></span><span>Email</span>
                            </label>

                        </div>

                        {
                            loading? 
                            <div className="loader-container">
                                <img src="assets/images/loader.gif" alt="loader" className="loader" />
                            </div>:
                            <div>
                                <input type="submit" className="register-button" value="Search" />
                            </div>
                        }
                        
                        {
                            flag===true?
                            <div className='login-form-grids'>
                                <b>Name:-</b>{udata.name}<br/>
                                <b>Phone:-</b>{udata.phone}<br/>
                                <b>Email:-</b>{udata.email}<br/>
                                <b>Roll NO:-</b>{udata.rollno}<br/>
                                <b>Semester:-</b>{udata.semester}<br/>
                                <b>Department:-</b>{udata.department}<br/>
                            </div>:null
                        }

                    </form>

                </div>

            </div>
        </>
    )
}

export default Searchuser
