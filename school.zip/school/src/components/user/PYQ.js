import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { json, Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import Footer from '../Footer';

function PYQ() {

    const[sempyq , setsempyq] = useState([]);
    const [selectedSemester, setSelectedSemester] = useState();
    const [semes, setsemes] = useState();
    const navigate = useNavigate()

    useEffect(() => {
        const storedSemester = parseInt(localStorage.getItem("selectedSemester"));
        if (storedSemester) {
            setSelectedSemester(storedSemester);
        }
    }, []);

    useEffect(() => {
        document.title = "PYQs";
    }, []);

    // useEffect(() => {
    //     const uniqueSemester = localStorage.getItem("OneSemester");
    //     if (uniqueSemester) {
    //         setsemes(uniqueSemester);
    //     }
    // }, []);

    const handleTabClick = (semester) => {
        setSelectedSemester(semester);
        localStorage.setItem("selectedSemester", semester);
        // localStorage.setItem("OneSemester", semester);
        // sessionStorage.setItem("onesem"  ,JSON.stringify(semes))
    };

    useEffect(()=>
    {
        setsemes(JSON.parse(sessionStorage.getItem("onesem")))
    },[])

    useEffect(()=>
    {
        if(semes)
        {
            // sessionStorage.setItem("onesem"  ,JSON.stringify(semes))
            fetchpyq();
        }
    }, [semes])

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navigate("/login")
            toast.error("please login to access the page")
        }
    },[])


    async function fetchpyq()
    {
        try
        {
            sessionStorage.setItem("onesem"  ,JSON.stringify(semes))
            
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchuserpyq/${semes}`)
            
            if(resp.data.statuscode===1)
            {
                setsempyq(resp.data.semesterpyq);
            }
            else if(resp.data.statuscode===0)
            {
                setsempyq([]);
            }
            else
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }


    return (
        <>
            <div class="container">
                <div class="content1">
                    <h1 class="title">
                        <span class="title-text">Previous Year Question Papers</span>
                    </h1>
                    <img src={`assets/images/underline.png`} alt="underline" className="underline-img2" />
                </div>

                <p class="description">
                     Access previous year question papers to enhance your preparation and boost your confidence for exams.
                </p>

                <div className="radio-container">
                    <div className="radio-inputs">
                        {
                            [1, 2, 3, 4, 5, 6, 7, 8 ].map((sem) => 
                            <label key={sem} >
                                <input type="radio" name="semester" value={sem} onClick={() => handleTabClick(sem)} onChange={(e)=>setsemes(e.target.value)} />
                                <span className={`name ${selectedSemester === sem ? 'activee' : ''}`}>Semester {sem}</span>
                            </label>
                        )}
                    </div>
                </div>

                {/* Dropdown for mobile screens */}
                <div class="dropdown-container">
                    <select class="custom-select"  onChange={(e)=>setsemes(e.target.value)} required>
                        <option value="">Choose Semester</option>
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                    </select>
                </div>

                {
                    sempyq.length > 0 ?
                    <>
                        <div class="youtube-container " >

                            {
                                sempyq.map((item , index)=>
                                
                                        <div class="youtube-card mb-5 mt-lg-5" key={index} data-aos="zoom-out" data-aos-duration="1000" data-aos-delay="100">
                                            <div class="icon-container ">
                                                <img src="assets/images/edit.svg" alt="source icon" class="source-icon" />
                                            </div>
                                            <p class="semester"><strong>Semester :&nbsp;</strong>{item.semester}</p>
                                            <p class="subject"><strong>Subject :&nbsp;</strong>{item.subject}</p>
                                            <p class="subject-code"><strong>Subject Code :&nbsp;</strong>{item.subjectcode}</p>
                                            <Link to={item.link1} target="_blank" class="channel-link"> Download PYQ 1 </Link>
                                            <Link to={item.link2} target="_blank" class="channel-link"> Download PYQ 2 </Link>
                                            <Link to={item.link3} target="_blank" class="channel-link"> Download PYQ 3 </Link>
                                        </div>
                                    
                                )
                            }
                        </div>

                    </>:
                    <div class="no-channel-message">
                        <h1>No YouTube channel for this semester at the moment.</h1>
                    </div>

                }
                
            </div>
            
            <Footer/>
        </>
    )
}

export default PYQ
