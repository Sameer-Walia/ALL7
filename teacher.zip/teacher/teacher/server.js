const express = require('express')
const app = express()
app.use(express.json());
const port = 7000

const cors = require('cors')
app.use(cors({
    origin: "http://localhost:3001",
    credentials: true
}))

const jwt = require("jsonwebtoken");

const cookieParser = require("cookie-parser")   // to read cookie for jwt
app.use(cookieParser());


const mongoose = require('mongoose');
const { type } = require('os');
mongoose.connect('mongodb://127.0.0.1:27017/teacherdb').then(() => console.log("Connected to MongoDB on port " + port));


const signupRoutes = require('./routes/signupRoutes');
app.use('/api', signupRoutes)

const teacherRoutes = require('./routes/teacherRoutes');
app.use('/api', teacherRoutes)

const feedbackRoutes = require('./routes/feedbackRoutes');
app.use('/api', feedbackRoutes)

const resetpasswordRoutes = require('./routes/resetpasswordRoutes');
app.use('/api', resetpasswordRoutes)


app.listen(port, () =>
{
    console.log(`Server is running on port ${port}`)
})