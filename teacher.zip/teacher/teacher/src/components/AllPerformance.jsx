import React, { useEffect, useState } from 'react';
import Adminpanel from './Adminpanel';
import axios from 'axios';
import { toast } from 'react-toastify';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

function AllPerformance() {
  const [allfeedbacks, setAllFeedbacks] = useState([]);

  useEffect(() => {
    getAllFeedbacks();
  }, []);

   useEffect(() => {
        document.title = "All Performances";
    }, []);
    

  async function getAllFeedbacks() 
  {
    try 
    {
      const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/getallfeedbacks`);
      if (resp.data.statuscode === 1) 
      {
        setAllFeedbacks(resp.data.feedbacks);
      } 
      else if (resp.data.statuscode === 0) 
      {
        setAllFeedbacks([]);
      }
      else 
      {
        toast.error("Some Problem Occurred");
      }
    } 
    catch (e) 
    {
      toast.error("Error Occured " + e.message)
    }
  }

  // Group feedbacks by same teacher name
  const grouped = allfeedbacks.reduce((acc, fb) => {
    if (!acc[fb.name]) acc[fb.name] = [];
    acc[fb.name].push(fb);
    return acc;
  }, {});

  // Calculate average for each teacher
  const labels = Object.keys(grouped);
  const averageRatings = labels.map(name => {
    const feedbacks = grouped[name];
    let total = 0;
    let count = 0;

    feedbacks.forEach(fb => {
      Object.keys(fb).forEach(key => {
        if (key.startsWith('rate')) {
          total += parseFloat(fb[key]);
          count++;
        }
      });
    });

    const avg = total / count;
    return avg.toFixed(2);
  });

  const data = {
    labels,
    datasets: [
      {
        label: 'Average Rating',
        data: averageRatings,
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
        borderRadius: 5,
        barThickness: 30
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { display: true, position: 'top' },
      title: {
        display: true,
        text: 'Admin Performance Analysis Panel',
        font: { size: 22 },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 5,
        title: { display: true, text: 'Rating', font: { size: 14 } },
        ticks: { stepSize: 0.5 }
      },
      x: {
        ticks: {
          maxRotation: 60,
          minRotation: 45,
          font: { size: 10 },
        },
        title: { display: true, text: 'Teachers', font: { size: 14 } },
      },
    },
  };

  return (
    <div>
      <Adminpanel />
      <div className='content1 pad'>
        <div className="chart-container" style={{ padding: '20px' }}>
          <Bar data={data} options={options} />
        </div>
      </div>
    </div>
  );
}

export default AllPerformance;
