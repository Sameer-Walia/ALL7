import React, { useEffect } from 'react'
import { Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import Home from './Home'
import About from './About'
import Authpage from './Authpage'
import ScrollToTop from './ScrollToTop'
import Dashboard from './Dashboard'
import Editprofile from './Editprofile'
import Contact from './Contact'
import AdminHome from './AdminHome'
import Adminuser from './admin/Adminuser'
import Updateuser from './admin/Updateuser'
import SearchUser from './admin/SearchUser'
import AdminContact from './admin/AdminContact'
import AdminTeacher from './admin/AdminTeacher'
import AddTeacher from './admin/AddTeacher'
import UpdateTeacher from './admin/UpdateTeacher'
import Feedback from './Feedback'
import Givefeedback from './Givefeedback'
import Givefeedback1 from './Givefeedback1'
import TeacherFeedbcak from './TeacherFeedbcak'
import AllPerformance from './AllPerformance'
import UniqueFeedback from './UniqueFeedback'
import AdminRouteProtector from './AdminRouteProtector'
import UserRouteProtector from './UserRouteProtector'
import Thanks from './Thanks'
import NoThanks from './NoThanks'
import ActivateAccount from './ActivateAccount'
import ChangePassword from './ChangePassword'
import ForgotPassword from './ForgotPassword'
import ResetPassword from './ResetPassword'
import Cookies from 'universal-cookie'

function Siteroutes()
{

  const navi = useNavigate()
  const usercookie = new Cookies()
  const location = useLocation();

  useEffect(() =>
  {
    const cookieUser = usercookie.get("staysignin");
    if (cookieUser)
    {
      try
      {
        const publicPaths = ["/"];

        if (publicPaths.includes(location.pathname))
        {
          if (cookieUser.usertype === "admin")
          {
            navi("/adminhome");
          }
          else
          {
            navi("/");
          }
        }
      }
      catch (err)
      {
        console.error("Error parsing cookie user:", err);
      }
    }
  }, [location.pathname]);

  return (
    <div>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/adminhome" element={<AdminRouteProtector compname={AdminHome} />}></Route>
        <Route path="/about" element={<About />}></Route>
        <Route path="/register" element={<Authpage />}></Route>
        <Route path="/thanks" element={<Thanks />}></Route>
        <Route path="/nothanks" element={<NoThanks />}></Route>
        <Route path="/activateaccount" element={<ActivateAccount />}></Route>
        <Route path="/login" element={<Authpage />}></Route>
        <Route path="/changepassword" element={<ChangePassword />}></Route>
        <Route path="/dashboard" element={<UserRouteProtector compname={Dashboard} />}></Route>
        <Route path="/editprofile" element={<UserRouteProtector compname={Editprofile} />}></Route>
        <Route path="/contact" element={<UserRouteProtector compname={Contact} />}></Route>
        <Route path="/adminuser" element={<AdminRouteProtector compname={Adminuser} />}></Route>
        <Route path="/updateuser" element={<AdminRouteProtector compname={Updateuser} />}></Route>
        <Route path="/searchuser" element={<AdminRouteProtector compname={SearchUser} />}></Route>
        <Route path="/admincontact" element={<AdminRouteProtector compname={AdminContact} />}></Route>
        <Route path="/adminteacher" element={<AdminRouteProtector compname={AdminTeacher} />}></Route>
        <Route path="/addteacher" element={<AdminRouteProtector compname={AddTeacher} />}></Route>
        <Route path="/updateteacher" element={<AdminRouteProtector compname={UpdateTeacher} />}></Route>
        <Route path="/feedback" element={<UserRouteProtector compname={Feedback} />}></Route>
        <Route path="/givefeedback" element={<UserRouteProtector compname={Givefeedback} />}></Route>

        {/* <Route path="/givefeedback1" element={<Givefeedback1/>}></Route> */}

        <Route path="/Teachers_Feedback" element={<AdminRouteProtector compname={TeacherFeedbcak} />}></Route>
        <Route path="/performance" element={<AdminRouteProtector compname={AllPerformance} />}></Route>
        <Route path="/getuniquefeedback" element={<AdminRouteProtector compname={UniqueFeedback} />}></Route>
        <Route path="/forgotpassword" element={<ForgotPassword />}></Route>
        <Route path="/resetpassword" element={<ResetPassword />}></Route>


      </Routes>
    </div>
  )
}

export default Siteroutes
