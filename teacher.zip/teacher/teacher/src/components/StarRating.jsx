import React, { useState } from 'react'

function StarRating() {

    let arr = new Array(5).fill(0)
    console.log(arr);

    const [rating, setrating] = useState(1);
    console.log(rating);

    const [hover, sethover] = useState(0);

    return (
        <div>
            <div class="rating">
                {
                    arr.map((item, index) => {
                        return (
                            <span key={index}
                                className={`${hover == 0 && index < rating || index < hover ? "filled" : ""} star `}
                                onClick={() => setrating(index + 1)}
                                onMouseEnter={() => sethover(index + 1)}
                                onMouseLeave={() => sethover(0)}>
                                &#9733;
                            </span>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default StarRating


