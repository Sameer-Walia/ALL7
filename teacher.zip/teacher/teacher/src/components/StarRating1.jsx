import React, { useState } from 'react'
function StarRating1() {

    let arr = new Array(5).fill(0)
    console.log(arr);

    const [rating, setrating] = useState(1);
    console.log(rating);

    const [hover, sethover] = useState(0);

    return (
        <div>
            <div class="rating">
                {
                    arr.map((item, index) => {
                        return (
                            <span key={index}
                                className={`${hover == 0 && index < rating || index < hover ? "filled" : ""} star `}
                                onClick={() => setrating(index + 1)}
                                onMouseEnter={() => sethover(index + 1)}
                                onMouseLeave={() => sethover(0)}>
                                &#9733;
                            </span>
                        )
                    })
                }
            </div>
        </div>
    )
}
export default StarRating1

// return (
//     <div>
        
//         <div class="rating">
//             <span class="star filled" data-index="0" data-forhalf="★">★</span>
//             <span class="star" data-index="1" data-forhalf="★">★</span>
//             <span class="star" data-index="2" data-forhalf="★">★</span>
//             <span class="star" data-index="3" data-forhalf="★">★</span>
//             <span class="star" data-index="4" data-forhalf="★">★</span>
//         </div>

//     </div>
// )

// }
// export default StarRating1

