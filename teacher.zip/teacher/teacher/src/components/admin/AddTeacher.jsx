import React, { useEffect, useState } from 'react'
import Adminpanel from '../Adminpanel'
import axios from 'axios';
import { toast } from 'react-toastify';
import { Navigate, useNavigate } from 'react-router-dom';

function AddTeacher() {

    const navigate = useNavigate()

    const [name, setname] = useState();
    const [phone, setphone] = useState();
    const [email, setemail] = useState();
    const [subjectname, setsubjectname] = useState();
    const [subjectcode, setsubjectcode] = useState();
    const [dep, setdep] = useState();
    const[loading , setloading] = useState(false);

    useEffect(() => {
        document.title = "Add Teacher";
    }, []);
    

    async function addteacher(e)
    {
        e.preventDefault()
        try
        {
            setloading(true)
            const tdata = {name , phone , email , subjectname , subjectcode , dep}
            const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/addteacher` , tdata)
           
            if (resp.data.statuscode === 1) 
            {
                toast.success("Teacher Added Successfully")
                navigate("/adminteacher")
            }
            else if (resp.data.statuscode === 0) 
            {
                toast.error("Cannot Added Teacher")
            }
            else 
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }


  return (
    <div>
        <Adminpanel/>
        <div className='content1'>

        <div class="text-center pt-3">
                    <h1 className='mhd'>Add Teacher Data</h1>
                </div>
                <section class="form-container ssss">
                    <form onSubmit={addteacher}>
                        <div class="form-group">
                            <label for="username">Name</label>
                            <input type="text" name="username" id="username" required  onChange={(e) => setname(e.target.value)} />
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" required  onChange={(e) => setemail(e.target.value)} />
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="tel" name="phone" id="phone" required  onChange={(e) => setphone(e.target.value)} />
                        </div>
                        
                        <div class="form-group">
                            <label for="department">Department</label>
                            <select
                                name="department"
                                id="department"
                                required
                                onChange={(e) => setdep(e.target.value)}
                            >
                                <option value="">Choose Department</option>
                                <option value="B.Tech Computer Science Engineering">B.Tech Computer Science Engineering</option>
                                <option value="B.Tech Electronics and Communication Engineering">B.Tech Electronics and Communication</option>
                                <option value="B.Tech Mechanical Engineering">B.Tech Mechanical Engineering</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="rollno">Subject</label>
                            <input type="text" name="rollno" id="rollno" required onChange={(e) => setsubjectname(e.target.value)} />
                        </div>

                        <div class="form-group">
                            <label for="rollno">Subject-Code</label>
                            <input type="text" name="rollno" id="rollno" required  onChange={(e) => setsubjectcode(e.target.value)} />
                        </div>
                        
                        {
                            loading? 
                            <div className="loader-container">
                                <img src="assets/images/loader.gif" alt="loader" className="loader" />
                            </div>:
                            <div class="form-actions ">
                                <input type="submit" className='subbtn1 mt-3' value="Add Teacher" />
                            </div>
                        }

                        
                    </form>
                </section>

            </div>

        </div>
  )
}

export default AddTeacher
